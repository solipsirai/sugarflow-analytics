"use client";
import { useEffect, useMemo, useState } from "react";
import { CommodityMath } from "./commodity-math";
import { BalanceChart } from "./balance-chart";
import { ReportClock } from "./report-clock";
type Data = {
  generatedAt: string;
  contracts: any[];
  weather: any[];
  cot: any | null;
  news: any[];
};
const views = [
  "Corn Overview",
  "Futures & Spreads",
  "Weather & Signals",
  "Crop Calendar",
  "S&D & Reports",
  "CFTC Positioning",
  "Exports & Ethanol",
  "Corn News",
  "Commodity Math",
  "Sources",
];
const fmt = (n: any, d = 2) =>
  Number.isFinite(n)
    ? Number(n).toLocaleString("en-US", { maximumFractionDigits: d })
    : "—";
function Tag({
  children,
  live = false,
}: {
  children: React.ReactNode;
  live?: boolean;
}) {
  return (
    <span className={live ? "ctag live" : "ctag"}>
      {live ? "● " : "◷ "}
      {children}
    </span>
  );
}
export function CornDesk({
  onCommodity,
}: {
  onCommodity: (x: "Sugar" | "Wheat" | "Corn") => void;
}) {
  const [data, setData] = useState<Data | null>(null),
    [view, setView] = useState(views[0]),
    [filter, setFilter] = useState("All");
  useEffect(() => {
    const load = () =>
      fetch("/api/corn")
        .then((r) => r.json())
        .then(setData)
        .catch(() =>
          setData({
            generatedAt: new Date().toISOString(),
            contracts: [],
            weather: [],
            cot: null,
            news: [],
          }),
        );
    load();
    const id = setInterval(load, 15 * 60 * 1000);
    return () => clearInterval(id);
  }, []);
  const go = (x: string) => {
    setView(x);
    scrollTo({ top: 0, behavior: "smooth" });
  };
  const front = data?.contracts.find((x) => x.symbol === "ZC=F");
  return (
    <main className="cornDesk">
      <header className="topbar">
        <button className="brand" onClick={() => go(views[0])}>
          <span>C</span>
          <div>
            <b>AGROFLOW</b>
            <small>CORN INTELLIGENCE</small>
          </div>
        </button>
        <div className="commoditySwitch">
          <button onClick={() => onCommodity("Sugar")}>Sugar</button>
          <button onClick={() => onCommodity("Wheat")}>Wheat</button>
          <button className="active">Corn</button>
        </div>
        <div className="status">
          {data ? "● CORN FEEDS BAĞLI" : "◌ BAĞLANIYOR"}
          <i>
            {data &&
              new Date(data.generatedAt).toLocaleTimeString("tr-TR", {
                hour: "2-digit",
                minute: "2-digit",
              })}
          </i>
        </div>
      </header>
      <section className="ticker cornTicker">
        <button onClick={() => go("Futures & Spreads")}>
          <span>CBOT CORN FRONT</span>
          <b>
            {fmt(front?.price)} <em>¢/bu</em>
          </b>
          <Tag>{front?.price != null ? "GECİKMELİ" : "VERİ YOK"}</Tag>
        </button>
        <button onClick={() => go("Futures & Spreads")}>
          <span>DEC NEW CROP</span>
          <b>
            {fmt(data?.contracts.find((x) => x.month === "Dec-26")?.price)}{" "}
            <em>¢/bu</em>
          </b>
          <Tag>NEW CROP</Tag>
        </button>
        <button onClick={() => go("CFTC Positioning")}>
          <span>CFTC MONEY NET</span>
          <b>{data?.cot ? fmt(data.cot.long - data.cot.short, 0) : "—"}</b>
          <Tag live={!!data?.cot}>HAFTALIK</Tag>
        </button>
        <button onClick={() => go("Weather & Signals")}>
          <span>CORN BELT REGIONS</span>
          <b>{data?.weather.length || 0}</b>
          <Tag live={!!data?.weather.length}>7 DAY</Tag>
        </button>
      </section>
      <div className="shell">
        <aside>
          <p className="eyebrow">CORN DESK</p>
          {views.map((v, i) => (
            <button
              key={v}
              className={view === v ? "selected" : ""}
              onClick={() => go(v)}
            >
              <i>{["⌁", "⇅", "☂", "◷", "▦", "◉", "⇄", "✦", "◎", "☷"][i]}</i>
              {v}
            </button>
          ))}
          <ReportClock includeEia />
        </aside>
        <section className="content">
          <div className="title">
            <div>
              <p className="eyebrow">GLOBAL CORN DESK / {view.toUpperCase()}</p>
              <h1>{view}</h1>
              <p>
                Corn Belt weather · CBOT new crop · exports · ethanol demand
              </p>
            </div>
            <Tag live={!!data}>15 DK CACHE</Tag>
          </div>
          {view === "Corn Overview" && <Overview data={data} go={go} />}{" "}
          {view === "Futures & Spreads" && <Futures data={data} />}{" "}
          {view === "Weather & Signals" && <Weather data={data} />}{" "}
          {view === "Crop Calendar" && <Calendar />}{" "}
          {view === "S&D & Reports" && <Reports />}{" "}
          {view === "CFTC Positioning" && <COT data={data} />}{" "}
          {view === "Exports & Ethanol" && <Exports />}{" "}
          {view === "Corn News" && (
            <News data={data} filter={filter} setFilter={setFilter} />
          )}{" "}
          {view === "Commodity Math" && <CommodityMath />}{" "}
          {view === "Sources" && <Sources />}
          <footer>
            <span>
              Signals are rule-based research notes, not trading advice.
            </span>
            <b>AGROFLOW · CORN v1</b>
          </footer>
        </section>
      </div>
    </main>
  );
}
function signal(data: Data | null) {
  if (!data?.weather.length)
    return { label: "Neutral", score: 0, why: "Weather feed loading" };
  let score = 0,
    heat = 0,
    dry = 0;
  for (const p of data.weather) {
    const rain = p.days.reduce((s: number, d: any) => s + d.rain, 0),
      et0 = p.days.reduce((s: number, d: any) => s + d.et0, 0),
      mx = Math.max(...p.days.map((d: any) => d.max));
    if (rain - et0 < -15) {
      score++;
      dry++;
    }
    if (mx > 34) {
      score++;
      heat++;
    }
    if (rain - et0 > 10) score--;
  }
  const ch = data.contracts.find((x) => x.symbol === "ZC=F")?.change;
  if (ch > 0) score++;
  if (ch < 0) score--;
  return {
    label: score >= 2 ? "Bullish" : score <= -2 ? "Bearish" : "Neutral",
    score,
    why: `${dry} dry-balance regions · ${heat} heat-watch regions · price ${ch > 0 ? "up" : ch < 0 ? "down" : "flat/unavailable"}`,
  };
}
function Overview({
  data,
  go,
}: {
  data: Data | null;
  go: (x: string) => void;
}) {
  const s = signal(data),
    net = data?.cot ? data.cot.long - data.cot.short : null;
  return (
    <>
      <div className={`signal cornSignal ${s.label.toLowerCase()}`}>
        <span>AUTOMATIC DESK READ</span>
        <b>
          {s.label} · Score {s.score > 0 ? "+" : ""}
          {s.score}
        </b>
        <p>
          {s.why}. Weather signal is stage-aware and recalculated with each feed
          refresh.
        </p>
        <strong>{s.label.toUpperCase()}</strong>
      </div>
      <div className="grid overview">
        <button className="card action" onClick={() => go("Weather & Signals")}>
          <Tag live={!!data?.weather.length}>WEATHER</Tag>
          <p className="eyebrow">US CORN BELT</p>
          <h2>{data?.weather.length || 0} regions</h2>
          <span>Heat / rain / ET₀ monitor →</span>
        </button>
        <button className="card action" onClick={() => go("CFTC Positioning")}>
          <Tag live={!!data?.cot}>CFTC</Tag>
          <p className="eyebrow">MANAGED MONEY NET</p>
          <h2>{fmt(net, 0)}</h2>
          <span>Crowding interpretation →</span>
        </button>
        <button className="card action" onClick={() => go("Exports & Ethanol")}>
          <Tag>DEMAND</Tag>
          <p className="eyebrow">EXPORT + ETHANOL</p>
          <h2>Two engines</h2>
          <span>Demand dashboard →</span>
        </button>
      </div>
      <div className="grid two">
        <article className="card">
          <p className="eyebrow">KEY DRIVERS</p>
          <h2>Daily Corn Checklist</h2>
          {[
            "Corn Belt heat and moisture by stage",
            "US yield/acreage revisions",
            "Export sales to China/Mexico/Japan",
            "EIA ethanol production and stocks",
            "Brazil safrinha + export competition",
            "Argentina crop and FX/policy",
            "Soy/corn acreage ratio and fertilizer",
            "USD, crude oil, gasoline and freight",
          ].map((x, i) => (
            <div className="health" key={x}>
              <span>{x}</span>
              <b>{String(i + 1).padStart(2, "0")}</b>
            </div>
          ))}
        </article>
        <article className="card">
          <p className="eyebrow">SEASONAL FOCUS</p>
          <h2>What Matters Now?</h2>
          {[
            ["Planting", "Pace, soil moisture, cold/wet delays"],
            [
              "Pollination",
              "Heat + moisture stress; highest yield sensitivity",
            ],
            ["Grain fill", "Kernel weight, heat, rainfall and disease"],
            ["Harvest", "Yield reports, moisture, basis and storage"],
            [
              "Post-harvest",
              "Demand, South America crop, acreage expectations",
            ],
          ].map((x) => (
            <div className="explain" key={x[0]}>
              <b>{x[0]}</b>
              <p>{x[1]}</p>
            </div>
          ))}
        </article>
      </div>
    </>
  );
}
function Futures({ data }: { data: Data | null }) {
  const rows = data?.contracts || [],
    sep = rows.find((x) => x.month === "Sep-26"),
    dec = rows.find((x) => x.month === "Dec-26"),
    mar = rows.find((x) => x.month === "Mar-27");
  return (
    <>
      <article className="card">
        <p className="eyebrow">CBOT / EURONEXT · DELAYED WHERE AVAILABLE</p>
        <h2>Corn Contract Board</h2>
        <div className="cornContractTable">
          <b>Contract</b>
          <b>Price</b>
          <b>Δ</b>
          <b>Volume</b>
          <b>Status / roll</b>
          <b>Source / time</b>
          {rows.map((q) => (
            <div className="cornContractTr" key={q.symbol}>
              <strong>
                {q.name}
                <small>{q.symbol}</small>
              </strong>
              <b>{fmt(q.price)} ¢/bu</b>
              <i className={(q.change || 0) >= 0 ? "up" : "down"}>
                {fmt(q.change)}
              </i>
              <span>{fmt(q.volume, 0)}</span>
              <em>
                {q.status}
                <small>
                  {q.roll} · LTD {q.lastTrade}
                </small>
              </em>
              <small>
                {q.source}
                <br />
                {q.asOf
                  ? new Date(q.asOf).toLocaleString("tr-TR")
                  : "timestamp yok"}
              </small>
            </div>
          ))}
        </div>
      </article>
      <div className="grid two">
        <article className="card">
          <p className="eyebrow">CALENDAR SPREADS</p>
          <h2>Curve Monitor</h2>
          {[
            [
              "Sep–Dec",
              sep?.price != null && dec?.price != null
                ? sep.price - dec.price
                : null,
            ],
            [
              "Dec–Mar",
              dec?.price != null && mar?.price != null
                ? dec.price - mar.price
                : null,
            ],
          ].map((x) => (
            <div className="heroMetric" key={x[0]}>
              <span>{x[0]}</span>
              <b>{x[1] == null ? "—" : `${Number(x[1]).toFixed(2)} ¢/bu`}</b>
            </div>
          ))}
          <p className="source">
            Positive nearby-minus-deferred may indicate tighter nearby supply;
            match contract crop years before interpretation.
          </p>
        </article>
        <article className="card">
          <p className="eyebrow">SPEC</p>
          <h2>CBOT Corn</h2>
          {[
            ["Contract", "5,000 bushels"],
            ["Bushel weight", "56 lb"],
            ["Minimum tick", "0.25¢/bu"],
            ["Tick value", "$12.50"],
            ["1.00¢ move", "$50/lot"],
            ["Months", "Mar May Jul Sep Dec"],
          ].map((x) => (
            <div className="health" key={x[0]}>
              <span>{x[0]}</span>
              <b>{x[1]}</b>
            </div>
          ))}
        </article>
      </div>
    </>
  );
}
function Weather({ data }: { data: Data | null }) {
  return (
    <div className="grid chartGrid">
      {(data?.weather || []).map((p) => {
        const rain = p.days.reduce((s: number, d: any) => s + d.rain, 0),
          et0 = p.days.reduce((s: number, d: any) => s + d.et0, 0),
          mx = Math.max(...p.days.map((d: any) => d.max)),
          bal = rain - et0,
          label =
            mx > 34 || bal < -15 ? "Bullish" : bal > 10 ? "Bearish" : "Neutral",
          note =
            label === "Bullish"
              ? "Weather threatens yield potential"
              : label === "Bearish"
                ? "Weather supports yield potential"
                : "No strong directional weather edge";
        return (
          <article className="card crop" key={p.id}>
            <p className="eyebrow">OPEN-METEO · {p.region}</p>
            <h2>{p.name}</h2>
            <div className={`autoSignal ${label.toLowerCase()}`}>
              <b>{label}</b>
              <span>{note}</span>
            </div>
            <div className="cropMeta">
              <b>{p.stage}</b>
              <span>7-day</span>
            </div>
            {[
              ["Rain", `${rain.toFixed(1)} mm`],
              ["ET₀", `${et0.toFixed(1)} mm`],
              ["Balance", `${bal.toFixed(1)} mm`],
              ["Max temp", `${mx.toFixed(1)}°C`],
            ].map((x) => (
              <div className="health" key={x[0]}>
                <span>{x[0]}</span>
                <b>{x[1]}</b>
              </div>
            ))}
          </article>
        );
      })}
    </div>
  );
}
function Calendar() {
  const now = new Date();
  const todayLeft = `calc(180px + (100% - 180px) * ${(now.getMonth() + (now.getDate() - 1) / new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate()) / 12})`;
  const months = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ],
    rows = [
      {
        n: "US Corn Belt",
        r: "IA IL IN MN NE OH SD",
        p: [4, 5, 6],
        g: [6, 7, 8, 9],
        h: [9, 10, 11],
      },
      {
        n: "Brazil 1st Crop",
        r: "South/Central",
        p: [9, 10, 11],
        g: [11, 12, 1, 2],
        h: [1, 2, 3, 4],
      },
      {
        n: "Brazil Safrinha",
        r: "MT PR GO MS",
        p: [1, 2, 3],
        g: [3, 4, 5, 6],
        h: [6, 7, 8],
      },
      {
        n: "Argentina",
        r: "Pampas",
        p: [9, 10, 11, 12],
        g: [11, 12, 1, 2, 3, 4],
        h: [3, 4, 5, 6, 7],
      },
      {
        n: "Ukraine",
        r: "Central/East",
        p: [4, 5],
        g: [5, 6, 7, 8, 9],
        h: [9, 10, 11],
      },
      {
        n: "EU",
        r: "France/Romania/Hungary",
        p: [3, 4, 5],
        g: [5, 6, 7, 8, 9],
        h: [9, 10, 11],
      },
      {
        n: "China",
        r: "NE China/North Plain",
        p: [4, 5, 6],
        g: [6, 7, 8, 9],
        h: [9, 10, 11],
      },
    ];
  return (
    <article className="card">
      <p className="eyebrow">GLOBAL CORN CROP CALENDAR</p>
      <h2>Planting · Growing · Harvest</h2>
      <div className="calendarScroll">
        <div className="calendarPosition">
          <div className="todayLine" style={{ left: todayLeft }}>
            <b>
              {now.toLocaleDateString("tr-TR", {
                day: "2-digit",
                month: "short",
              })}
            </b>
          </div>
          <div className="wheatCalendar">
            <b>Origin / region</b>
            {months.map((m) => (
              <b key={m}>{m}</b>
            ))}
            {rows.map((r) => (
              <div className="wheatCalRow" key={r.n}>
                <strong>
                  {r.n}
                  <small>{r.r}</small>
                </strong>
                {months.map((_, i) => {
                  const m = i + 1,
                    cls = r.h.includes(m)
                      ? "harvest"
                      : r.p.includes(m)
                        ? "plant"
                        : r.g.includes(m)
                          ? "grow"
                          : "";
                  return (
                    <span className={cls} key={m}>
                      {cls === "harvest"
                        ? "H"
                        : cls === "plant"
                          ? "P"
                          : cls === "grow"
                            ? "G"
                            : ""}
                    </span>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="calendarLegend">
        <span>
          <i className="plant" />
          Planting
        </span>
        <span>
          <i className="grow" />
          Growing
        </span>
        <span>
          <i className="harvest" />
          Harvest
        </span>
      </div>
    </article>
  );
}
function Reports() {
  return (
    <div className="grid two">
      <BalanceChart
        title="U.S. Corn 2026/27"
        unit="Million bushels"
        values={[
          ["Production", 16013],
          ["Domestic use", 13055],
          ["Exports", 3275, "export"],
          ["Ending stocks", 1653, "stock"],
        ]}
      />
      <BalanceChart
        title="Corn WASDE Revision"
        unit="July → August 2026"
        values={[
          ["Yield Jul (bu/ac)", 183],
          ["Yield Aug (bu/ac)", 180.7],
          ["Exports Jul (M bu)", 3200, "export"],
          ["Exports Aug (M bu)", 3275, "export"],
          ["Stocks Jul (M bu)", 1790, "stock"],
          ["Stocks Aug (M bu)", 1653, "stock"],
        ]}
      />
      <article className="card">
        <p className="eyebrow">USDA REPORT STACK</p>
        <h2>What to Monitor</h2>
        {[
          [
            "WASDE",
            "Production, feed, ethanol, exports, stocks/use",
            "Monthly",
          ],
          [
            "Crop Progress",
            "Planting, emergence, silking, condition, harvest",
            "Monday",
          ],
          ["Acreage", "Planted/harvested acres", "June + updates"],
          ["Grain Stocks", "Residual use and stock reset", "Quarterly"],
          ["Crop Production", "Yield/area revisions", "Monthly in season"],
          ["Export Sales", "Sales, cancellations, destinations", "Thursday"],
          ["Export Inspections", "Shipments by destination", "Monday"],
          ["EIA Ethanol", "Production and stocks", "Wednesday"],
        ].map((x) => (
          <div className="reportRow" key={x[0]}>
            <b>{x[0]}</b>
            <span>{x[1]}</span>
            <i>{x[2]}</i>
          </div>
        ))}
      </article>
      <article className="card">
        <p className="eyebrow">WASDE READING ORDER</p>
        <h2>Corn Balance Logic</h2>
        {[
          "Yield × harvested area = production",
          "Feed & residual demand",
          "Ethanol grind",
          "Exports and competitor supply",
          "Ending stocks",
          "Stocks/use",
          "Farm price projection",
        ].map((x, i) => (
          <div className="health" key={x}>
            <span>{x}</span>
            <b>{i + 1}</b>
          </div>
        ))}
      </article>
    </div>
  );
}
function COT({ data }: { data: Data | null }) {
  const c = data?.cot;
  if (!c)
    return (
      <article className="card empty">
        <h2>CFTC data loading</h2>
      </article>
    );
  const net = c.long - c.short,
    share = c.openInterest ? (net / c.openInterest) * 100 : 0;
  return (
    <div className="grid two">
      <article className="card">
        <p className="eyebrow">CFTC PRE · {c.date}</p>
        <h2>CBOT Corn Managed Money</h2>
        <div className="heroMetric">
          <span>Net</span>
          <b className={net >= 0 ? "up" : "down"}>{fmt(net, 0)}</b>
        </div>
        {[
          ["Long", c.long],
          ["Short", c.short],
          ["Spreading", c.spread],
          ["Open interest", c.openInterest],
          ["Net/OI", `${share.toFixed(1)}%`],
        ].map((x) => (
          <div className="health" key={x[0]}>
            <span>{x[0]}</span>
            <b>{typeof x[1] === "number" ? fmt(x[1], 0) : x[1]}</b>
          </div>
        ))}
      </article>
      <article className="card">
        <p className="eyebrow">AUTOMATIC READ</p>
        <h2>{net < 0 ? "Net short positioning" : "Net long positioning"}</h2>
        <p className="deskNote">
          {net < 0
            ? "Bullish catalyst can trigger short-covering, but short position alone is not a buy signal."
            : "Crowded longs increase liquidation risk if yield, exports or ethanol disappoint."}
        </p>
      </article>
    </div>
  );
}
function Exports() {
  return (
    <div className="grid two">
      <article className="card">
        <p className="eyebrow">EXPORT DEMAND</p>
        <h2>Destinations & Competitors</h2>
        {[
          ["Mexico", "Core/structural US buyer"],
          ["Japan", "Regular feed demand"],
          ["China", "Large but policy-sensitive"],
          ["Colombia", "US Gulf logistics"],
          ["South Korea", "Price-sensitive feed buyer"],
          ["Brazil/Argentina/Ukraine", "Main export competition"],
        ].map((x) => (
          <div className="origin" key={x[0]}>
            <b>{x[0]}</b>
            <span>{x[1]}</span>
          </div>
        ))}
      </article>
      <article className="card">
        <p className="eyebrow">ETHANOL DEMAND</p>
        <h2>Weekly Grind Watch</h2>
        {[
          ["EIA production", "Corn grind proxy"],
          ["Ethanol stocks", "Demand/export balance"],
          ["Gasoline demand", "Blending pool"],
          ["Crush margin", "Plant incentive"],
          ["Corn basis", "Local plant demand"],
          ["DDGS value", "Co-product credit"],
          ["RINs / policy", "Mandate economics"],
        ].map((x) => (
          <div className="health" key={x[0]}>
            <span>{x[0]}</span>
            <b>{x[1]}</b>
          </div>
        ))}
      </article>
    </div>
  );
}
function News({
  data,
  filter,
  setFilter,
}: {
  data: Data | null;
  filter: string;
  setFilter: (x: string) => void;
}) {
  const fs = ["All", "Corn", "Weather", "Trade", "Ethanol"],
    shown = (data?.news || []).filter(
      (n) => filter === "All" || n.category === filter,
    );
  return (
    <>
      <div className="newsHero">
        <div>
          <p className="eyebrow">FREE CORN NEWS DISCOVERY</p>
          <h2>{shown.length} corn stories</h2>
          <p>
            Searches the open web through GDELT and opens the original
            publisher. Official USDA/EIA sources remain the primary data
            references.
          </p>
        </div>
      </div>
      <div className="newsFilters">
        {fs.map((f) => (
          <button
            className={filter === f ? "active" : ""}
            onClick={() => setFilter(f)}
            key={f}
          >
            {filter === f ? "● " : ""}
            {f}
          </button>
        ))}
      </div>
      <div className="newsList">
        {shown.map((n, i) => (
          <a
            href={n.url}
            target="_blank"
            rel="noopener noreferrer"
            className="newsItem"
            key={n.url}
          >
            <div className="newsIndex">{String(i + 1).padStart(2, "0")}</div>
            <div>
              <p className="eyebrow">
                {n.domain} · {n.source} · {n.date?.slice(0, 8)}
              </p>
              <h3>{n.title}</h3>
              <span>{n.category.toUpperCase()}</span>
            </div>
            <b>↗</b>
          </a>
        ))}
      </div>
    </>
  );
}
function Sources() {
  const rows = [
    [
      "CME Group",
      "Corn futures specs/calendar/settlements",
      "Official exchange",
      "Live license",
    ],
    [
      "USDA NASS",
      "Crop progress, acreage, stocks, production",
      "Official",
      "Free",
    ],
    ["USDA WASDE/PSD", "US/world S&D", "Official", "Free"],
    ["USDA FAS", "Export sales/inspections/PSD", "Official", "Free"],
    ["EIA", "Ethanol production and stocks", "Official", "Free"],
    ["CFTC PRE", "Managed Money, producer, OI", "Official API", "Free"],
    ["Open-Meteo", "Rain, temperature, ET₀", "Open API", "Free"],
    ["GDELT", "Open-web news discovery", "Aggregator", "Free"],
    ["USDA AMS", "Cash grain/basis", "Official", "Free"],
    [
      "LSEG/Bloomberg/CME vendor",
      "Realtime futures/options/news",
      "Licensed",
      "Enterprise",
    ],
  ];
  return (
    <article className="card">
      <p className="eyebrow">DATA LINEAGE</p>
      <h2>Corn Sources</h2>
      <div className="sourceTable">
        <b>Source</b>
        <b>Data</b>
        <b>Quality</b>
        <b>Access</b>
        {rows.map((r) => (
          <div className="sourceTr" key={r[0]}>
            <strong>{r[0]}</strong>
            <span>{r[1]}</span>
            <span>{r[2]}</span>
            <span>{r[3]}</span>
          </div>
        ))}
      </div>
    </article>
  );
}
