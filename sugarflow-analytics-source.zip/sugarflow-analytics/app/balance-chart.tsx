export function BalanceChart({
  title,
  unit,
  values,
}: {
  title: string;
  unit: string;
  values: Array<[string, number, string?]>;
}) {
  const max = Math.max(...values.map((x) => x[1]));
  return (
    <article className="card balanceCard">
      <p className="eyebrow">USDA WASDE · 12 AUG 2026</p>
      <h2>{title}</h2>
      <p className="chartUnit">{unit}</p>
      <div className="balanceBars">
        {values.map(([label, value, tone]) => (
          <div className="balanceBar" key={label}>
            <span>{label}</span>
            <div>
              <i
                className={tone || ""}
                style={{ width: `${Math.max(4, (value / max) * 100)}%` }}
              />
            </div>
            <b>{value.toLocaleString("en-US", { maximumFractionDigits: 2 })}</b>
          </div>
        ))}
      </div>
    </article>
  );
}
