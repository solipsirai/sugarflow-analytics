"use client";
import { useEffect, useMemo, useState } from "react";
import { ContractBoard, SmartDataHub } from "./advanced-tools";
import { CepeaPanel, GlobalBalance } from "./fixed-widgets";
import { OptionTerminal } from "./option-terminal";
import { WheatDesk } from "./wheat-desk";
import { CornDesk } from "./corn-desk";
import { CommodityMath } from "./commodity-math";
type ContractQuote = {
  symbol: string;
  name: string;
  price: number | null;
  change: number | null;
  volume: number | null;
  currency: string;
  unit: string;
  asOf: string | null;
  source: string;
  status: "delayed" | "unavailable";
  contractState: string;
  lastTrade: string | null;
  rollWatch: string | null;
};
type Live = {
  generatedAt: string;
  fx: null | { value: number; date: string };
  cot: null | {
    date: string;
    moneyLong: number;
    moneyShort: number;
    producerLong: number;
    producerShort: number;
    openInterest: number;
  };
  weather: null | Array<{
    id: string;
    name: string;
    stage: string;
    days: Array<{
      date: string;
      max: number;
      min: number;
      rain: number;
      prob: number;
    }>;
  }>;
  news: Array<{
    title: string;
    url: string;
    domain: string;
    date: string;
    image: string | null;
    language: string;
    category: "Şeker" | "Etanol" | "Brezilya" | "Hindistan" | "Politika";
    source: string;
  }>;
  contracts: ContractQuote[];
};
const demo = { raw: 16.84, white: 468.7, ethanol: 2.73 };
const menu = [
  "Genel Bakış",
  "Research Calendar",
  "Key Drivers",
  "Haber Arşivi",
  "Futures & Spreads",
  "Fiziksel / FOB",
  "Etanol & Pariteler",
  "S&D Dengeleri",
  "Trade Flows",
  "Brezilya CS",
  "CFTC Pozisyonları",
  "Crop Conditions",
  "Crop Calendar",
  "Opsiyon & Risk",
  "Commodity Math",
  "Data Hub",
  "Kaynak Kataloğu",
  "Lisans Matrisi",
];
const nav: Record<string, string> = {
  Piyasa: "Genel Bakış",
  Takvim: "Research Calendar",
  Haberler: "Haber Arşivi",
  Flows: "Trade Flows",
  Fundamentaller: "Key Drivers",
  "Crop Monitor": "Crop Conditions",
  Araçlar: "Opsiyon & Risk",
};
function Spark({
  data,
  color = "#d9ff43",
}: {
  data: number[];
  color?: string;
}) {
  let mn = Math.min(...data),
    mx = Math.max(...data),
    pts = data
      .map(
        (v, i) =>
          `${(i / (data.length - 1)) * 100},${38 - ((v - mn) / (mx - mn || 1)) * 32}`,
      )
      .join(" ");
  return (
    <svg viewBox="0 0 100 42" preserveAspectRatio="none">
      <polyline
        points={pts}
        fill="none"
        stroke={color}
        strokeWidth="1.5"
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
}
function Badge({
  live = false,
  children,
}: {
  live?: boolean;
  children: React.ReactNode;
}) {
  return (
    <span className={live ? "badge live" : "badge"}>
      {live ? "● CANLI" : "◷ " + children}
    </span>
  );
}
export default function Home() {
  const [commodity, setCommodity] = useState<"Sugar" | "Wheat" | "Corn">(
      "Sugar",
    ),
    [view, setView] = useState("Genel Bakış"),
    [data, setData] = useState<Live | null>(null),
    [lots, setLots] = useState(10),
    [entry, setEntry] = useState(16.25),
    [target, setTarget] = useState(17.1),
    [side, setSide] = useState("LONG"),
    [premium, setPremium] = useState(42),
    [weatherTab, setWeatherTab] = useState(0),
    [alerts, setAlerts] = useState(false);
  useEffect(() => {
    const load = () =>
      fetch("/api/market")
        .then((r) => r.json())
        .then((x: Live) => {
          setData(x);
          if (
            typeof Notification !== "undefined" &&
            Notification.permission === "granted" &&
            localStorage.getItem("sugarflow-alerts") === "on" &&
            x.news?.[0]
          ) {
            const old = localStorage.getItem("sugarflow-last-news");
            if (old && old !== x.news[0].url) {
              const notification = new Notification(
                "SugarFlow · Yeni piyasa haberi",
                {
                  body: x.news[0].title,
                  tag: x.news[0].url,
                },
              );
              notification.onclick = () => {
                window.focus();
                window.open(x.news[0].url, "_blank", "noopener,noreferrer");
                notification.close();
              };
            }
            localStorage.setItem("sugarflow-last-news", x.news[0].url);
          }
        });
    load();
    const id = setInterval(load, 15 * 60 * 1000);
    setAlerts(localStorage.getItem("sugarflow-alerts") === "on");
    return () => clearInterval(id);
  }, []);
  const enableAlerts = async () => {
    if (typeof Notification === "undefined")
      return alert("Bu tarayıcı bildirimleri desteklemiyor.");
    const p = await Notification.requestPermission();
    if (p === "granted") {
      localStorage.setItem("sugarflow-alerts", "on");
      setAlerts(true);
      new Notification("SugarFlow bildirimleri açıldı", {
        body: "Yeni şeker ve etanol haberlerini site açıkken bildireceğim.",
      });
    }
  };
  const pnl = useMemo(
      () => (side === "LONG" ? 1 : -1) * (target - entry) * 1120 * lots,
      [side, target, entry, lots],
    ),
    fx = data?.fx?.value;
  const go = (x: string) => {
    setView(x);
    scrollTo({ top: 0, behavior: "smooth" });
  };
  const csv = () => {
    const rows = [
      ["metric", "value", "status"],
      ["NY11", demo.raw, "demo"],
      ["London5", demo.white, "demo"],
      ["USDBRL", fx || "N/A", "live"],
      [
        "CFTC Net",
        data?.cot ? data.cot.moneyLong - data.cot.moneyShort : "N/A",
        "live",
      ],
    ];
    const a = document.createElement("a");
    a.href = URL.createObjectURL(
      new Blob([rows.map((x) => x.join(",")).join("\n")], { type: "text/csv" }),
    );
    a.download = "sugarflow-data.csv";
    a.click();
  };
  if (commodity === "Wheat") return <WheatDesk onCommodity={setCommodity} />;
  if (commodity === "Corn") return <CornDesk onCommodity={setCommodity} />;
  return (
    <main>
      <header className="topbar">
        <button className="brand" onClick={() => go("Genel Bakış")}>
          <span>S</span>
          <div>
            <b>SUGARFLOW</b>
            <small>MARKET INTELLIGENCE</small>
          </div>
        </button>
        <nav>
          {Object.keys(nav).map((x) => (
            <button
              key={x}
              className={view === nav[x] ? "active" : ""}
              onClick={() => go(nav[x])}
            >
              {x}
            </button>
          ))}
        </nav>
        <div className="commoditySwitch">
          <button className="active">Sugar</button>
          <button onClick={() => setCommodity("Wheat")}>Wheat</button>
          <button onClick={() => setCommodity("Corn")}>Corn</button>
        </div>
        <div className="status">
          {data ? "● VERİ BAĞLI" : "◌ BAĞLANIYOR"}
          <i>
            {data &&
              new Date(data.generatedAt).toLocaleTimeString("tr-TR", {
                hour: "2-digit",
                minute: "2-digit",
              })}
          </i>
        </div>
      </header>
      <section className="ticker">
        <button onClick={() => go("Futures & Spreads")}>
          <span>NY #11 FRONT</span>
          <b>
            {data?.contracts
              ?.find((x) => x.symbol === "SB=F")
              ?.price?.toFixed(2) || "—"}{" "}
            <em>¢/lb</em>
          </b>
          <Badge>GECİKMELİ</Badge>
        </button>
        <button onClick={() => go("Futures & Spreads")}>
          <span>LONDON #5 FRONT</span>
          <b>
            {data?.contracts
              ?.find((x) => x.symbol === "SW=F")
              ?.price?.toFixed(2) || "—"}{" "}
            <em>$/t</em>
          </b>
          <Badge>GECİKMELİ</Badge>
        </button>
        <button onClick={() => go("CFTC Pozisyonları")}>
          <span>CFTC MONEY NET</span>
          <b>
            {data?.cot
              ? ((data.cot.moneyLong - data.cot.moneyShort) / 1000).toFixed(1) +
                "K"
              : "—"}
          </b>
          <Badge live={!!data?.cot}>HAFTALIK</Badge>
        </button>
        <button onClick={() => go("Genel Bakış")}>
          <span>USD / BRL</span>
          <b>{fx?.toFixed(4) || "—"}</b>
          <Badge live={!!fx}>GÜNLÜK</Badge>
        </button>
        <button onClick={() => go("Etanol & Pariteler")}>
          <span>CEPEA ETHANOL + SUGAR</span>
          <b>
            RESMÎ <em>KAYNAK</em>
          </b>
          <Badge>30 DK</Badge>
        </button>
      </section>
      <div className="shell">
        <aside>
          <p className="eyebrow">ÇALIŞMA ALANI</p>
          {menu.map((x, i) => (
            <button
              onClick={() => go(x)}
              className={view === x ? "selected" : ""}
              key={x}
            >
              <i>
                {
                  [
                    "⌁",
                    "◷",
                    "◆",
                    "✦",
                    "⌁",
                    "◎",
                    "◐",
                    "▦",
                    "⇄",
                    "◈",
                    "◉",
                    "☂",
                    "◷",
                    "◒",
                    "◎",
                    "⊕",
                    "☷",
                    "⚿",
                  ][i]
                }
              </i>
              {x}
            </button>
          ))}
          <button
            className={alerts ? "alertBtn on" : "alertBtn"}
            onClick={enableAlerts}
          >
            🔔 {alerts ? "Bildirimler Açık" : "Bildirimleri Aç"}
          </button>
          <div className="watch">
            <p className="eyebrow">VERİ TAZELİĞİ</p>
            {[
              ["UNICA", 5],
              ["CFTC", 3],
              ["NOAA ENSO", 8],
              ["ISMA", 31],
              ["WASDE", 11],
            ].map((x) => (
              <div key={String(x[0])}>
                <b>{x[0]}</b>
                <span
                  className={
                    (x[1] as number) <= 7
                      ? "ok"
                      : (x[1] as number) <= 14
                        ? "warn"
                        : "down"
                  }
                >
                  ● {x[1]} days old
                </span>
              </div>
            ))}
          </div>
        </aside>
        <section className="content">
          <div className="title">
            <div>
              <p className="eyebrow">
                GLOBAL SUGAR DESK / {view.toUpperCase()}
              </p>
              <h1>{view}</h1>
              <p>
                Resmî ve açık veri kaynakları · Demo fiyatlar açıkça işaretlidir
              </p>
            </div>
            <button className="outline" onClick={csv}>
              ↓ CSV DIŞA AKTAR
            </button>
          </div>
          {view === "Genel Bakış" && <Overview data={data} go={go} />}{" "}
          {view === "Research Calendar" && <ResearchCalendar />}{" "}
          {view === "Key Drivers" && <Drivers data={data} />}{" "}
          {view === "Haber Arşivi" && (
            <News
              news={data?.news || []}
              alerts={alerts}
              enable={enableAlerts}
            />
          )}{" "}
          {view === "Futures & Spreads" && (
            <ContractBoard contracts={data?.contracts || []} />
          )}{" "}
          {view === "Fiziksel / FOB" && (
            <Physical premium={premium} setPremium={setPremium} />
          )}{" "}
          {view === "Etanol & Pariteler" && <CepeaPanel />}{" "}
          {view === "S&D Dengeleri" && <GlobalBalance />}{" "}
          {view === "Trade Flows" && <TradeFlows />}{" "}
          {view === "Brezilya CS" && <Brazil />}{" "}
          {view === "CFTC Pozisyonları" && <CFTC cot={data?.cot} />}{" "}
          {view === "Crop Conditions" && (
            <CropConditions weather={data?.weather} />
          )}{" "}
          {view === "Crop Calendar" && <Calendar />}{" "}
          {view === "Opsiyon & Risk" && <OptionTerminal />}{" "}
          {view === "Commodity Math" && <CommodityMath />}{" "}
          {view === "Data Hub" && <SmartDataHub />}{" "}
          {view === "Kaynak Kataloğu" && <SourceCatalog />}{" "}
          {view === "Lisans Matrisi" && <Licenses />}
          <footer>
            <span>
              Research Calendar günlük/haftalık/aylık desk rutinini gösterir;
              kaynak kataloğu her verinin kökenini açıklar.
            </span>
            <b>SUGARFLOW v0.5</b>
          </footer>
        </section>
      </div>
    </main>
  );
}
function Overview({
  data,
  go,
}: {
  data: Live | null;
  go: (x: string) => void;
}) {
  const w = data?.weather?.[0]?.days[0],
    net = data?.cot ? data.cot.moneyLong - data.cot.moneyShort : 0,
    rain7 = data?.weather?.[0]?.days.reduce((s, d) => s + d.rain, 0) || 0,
    pxChange = data?.contracts?.find((x) => x.symbol === "SB=F")?.change || 0,
    score =
      (rain7 > 35 ? 1 : rain7 < 8 ? -1 : 0) +
      (pxChange > 0 ? 1 : pxChange < 0 ? -1 : 0),
    read = score >= 2 ? "Bullish" : score <= -2 ? "Bearish" : "Neutral";
  return (
    <>
      <div className="signal">
        <span>AUTOMATIC SUGAR DESK READ</span>
        <b>
          {read} · Score {score > 0 ? "+" : ""}
          {score}
        </b>
        <p>
          Brazil 7d rain: {rain7.toFixed(1)} mm · NY11{" "}
          {pxChange > 0 ? "up" : pxChange < 0 ? "down" : "flat/unavailable"} ·
          funds {net < 0 ? "net short" : "net long"}. USD/BRL:{" "}
          {data?.fx?.value?.toFixed(4) || "—"}.
        </p>
        <strong>{read.toUpperCase()}</strong>
      </div>
      <div className="grid overview">
        <button className="card action" onClick={() => go("CFTC Pozisyonları")}>
          <Badge live={!!data?.cot}>CFTC</Badge>
          <p className="eyebrow">FON POZİSYONU</p>
          <h2>{data?.cot ? (net / 1000).toFixed(1) + "K" : "—"}</h2>
          <span>Managed Money detayını aç →</span>
        </button>
        <button className="card action" onClick={() => go("Crop Conditions")}>
          <Badge live={!!data?.weather}>HAVA</Badge>
          <p className="eyebrow">RIBEIRÃO PRETO</p>
          <h2>{w ? `${w.max}°C · ${w.rain} mm` : "Veri bekleniyor"}</h2>
          <span>Hava ve crop riskini aç →</span>
        </button>
        <button className="card action" onClick={() => go("Fiziksel / FOB")}>
          <Badge>HESAPLAYICI</Badge>
          <p className="eyebrow">BRAZIL VHP FOB</p>
          <h2>NY11 + premium</h2>
          <span>Fiziksel fiyatı hesapla →</span>
        </button>
      </div>
      <div className="grid main-grid">
        <article className="card">
          <div className="cardhead">
            <div>
              <p className="eyebrow">ICE US · DEMO REFERANS</p>
              <h2>NY #11 Raw Sugar</h2>
            </div>
            <div className="quote">
              <b>{demo.raw}</b>
              <span>¢/lb</span>
              <Badge>ICE LİSANSI</Badge>
            </div>
          </div>
          <div className="bigchart">
            <Spark
              data={[
                17.8, 17.5, 17.7, 17.2, 16.9, 17.1, 16.6, 16.2, 16.5, 16.1,
                15.8, 16, 16.4, 16.2, 16.7, 16.84,
              ]}
            />
            <span>{demo.raw}</span>
          </div>
        </article>
        <article className="card">
          <p className="eyebrow">CANLI BAĞLANTILAR</p>
          <h2>Veri Sağlığı</h2>
          {[
            ["CFTC weekly positioning", !!data?.cot],
            ["USD/BRL reference", !!data?.fx],
            ["3 origin weather", !!data?.weather],
            ["ICE futures", false],
            ["FOB premiums", false],
          ].map((x) => (
            <div className="health" key={String(x[0])}>
              <span>{x[0]}</span>
              <b className={x[1] ? "up" : "warn"}>
                {x[1] ? "● BAĞLI" : "◷ LİSANS/INPUT"}
              </b>
            </div>
          ))}
        </article>
      </div>
    </>
  );
}
function Futures({ contracts }: { contracts: ContractQuote[] }) {
  const valid = contracts.filter((x) => x.price != null);
  return (
    <>
      <article className="card">
        <div className="cardhead">
          <div>
            <p className="eyebrow">CONTRACT BOARD · 15 DK CACHE</p>
            <h2>Şeker Kontrat Fiyatları</h2>
          </div>
          <Badge>EXCHANGE-DELAYED</Badge>
        </div>
        <div className="contractTable">
          <b>Kontrat</b>
          <b>Fiyat</b>
          <b>Değişim</b>
          <b>Zaman</b>
          <b>Kaynak / kalite</b>
          {contracts.map((q) => (
            <div className="contractTr" key={q.symbol}>
              <strong>
                {q.name}
                <small>{q.symbol}</small>
              </strong>
              <b>
                {q.price == null ? "—" : q.price.toFixed(2)} {q.unit}
              </b>
              <i className={(q.change || 0) >= 0 ? "up" : "down"}>
                {q.change == null
                  ? "—"
                  : `${q.change >= 0 ? "+" : ""}${q.change.toFixed(2)}`}
              </i>
              <span>
                {q.asOf
                  ? new Date(q.asOf).toLocaleString("tr-TR", {
                      dateStyle: "short",
                      timeStyle: "short",
                    })
                  : "Yok"}
              </span>
              <em>{q.source}</em>
            </div>
          ))}
        </div>
        <p className="source">
          Kaynak: Yahoo Finance chart endpoint. Fiyatlar borsa gecikmeli
          olabilir; resmî ICE settlement değildir. Kurumsal kullanım ve yeniden
          dağıtım için ICE/LSEG/Bloomberg lisansı gerekir.
        </p>
      </article>
      <div className="grid two">
        <article className="card">
          <p className="eyebrow">IMPLIED CURVE</p>
          <h2>Bağlı Kontratlar</h2>
          {valid.length ? (
            valid.map((q, i) => (
              <div className="curve" key={q.symbol}>
                <span>{q.symbol}</span>
                <i style={{ width: `${45 + i * 12}%` }} />
                <b>
                  {q.price?.toFixed(2)} {q.unit}
                </b>
              </div>
            ))
          ) : (
            <div className="empty">
              Kaynak yanıt vermedi; demo fiyat göstermiyoruz.
            </div>
          )}
        </article>
        <UnitConverter />
      </div>
    </>
  );
}
function Physical({
  premium,
  setPremium,
}: {
  premium: number;
  setPremium: (x: number) => void;
}) {
  const base = demo.raw * 22.0462,
    total = base + premium;
  return (
    <div className="grid two">
      <article className="card">
        <p className="eyebrow">FİZİKSEL FİYAT HESAPLAYICI</p>
        <h2>NY11 + Premium → USD/MT</h2>
        <div className="form">
          <label>
            Ürün
            <select>
              <option>Brazil VHP</option>
              <option>Brazil ICUMSA 45</option>
              <option>Thailand Hi-Pol</option>
            </select>
          </label>
          <label>
            NY #11 (¢/lb)
            <input value={demo.raw} readOnly />
          </label>
          <label>
            Premium (USD/MT)
            <input
              type="number"
              value={premium}
              onChange={(e) => setPremium(+e.target.value)}
            />
          </label>
        </div>
        <div className="formula">
          <span>{demo.raw} × 22.0462</span>
          <b>${base.toFixed(2)}/MT</b>
          <i>+</i>
          <span>Premium</span>
          <b>${premium.toFixed(2)}/MT</b>
          <strong>${total.toFixed(2)} / MT</strong>
        </div>
      </article>
      <article className="card">
        <p className="eyebrow">ORIGIN BOARD</p>
        <h2>Fiziksel Bazlar</h2>
        {[
          ["Brazil VHP", "Santos", "NY11 + input"],
          ["Brazil ICUMSA 45", "Santos", "White premium"],
          ["Thailand Hi-Pol", "Laem Chabang", "#5 basis"],
          ["India White", "West Coast", "Policy-sensitive"],
        ].map((r) => (
          <div className="origin" key={r[0]}>
            <b>{r[0]}</b>
            <span>{r[1]}</span>
            <i>{r[2]}</i>
          </div>
        ))}
        <p className="source">
          FOB teklifleri halka açık standart bir feed değildir.
          Broker/Platts/Fastmarkets/CZ inputu bağlanabilir.
        </p>
      </article>
    </div>
  );
}
function News({
  news,
  alerts,
  enable,
}: {
  news: Live["news"];
  alerts: boolean;
  enable: () => void;
}) {
  const filters = [
      "Tümü",
      "Şeker",
      "Etanol",
      "Brezilya",
      "Hindistan",
      "Politika",
    ] as const,
    [active, setActive] = useState<(typeof filters)[number]>("Tümü");
  const shown =
    active === "Tümü" ? news : news.filter((n) => n.category === active);
  return (
    <>
      <div className="newsHero">
        <div>
          <p className="eyebrow">SUGAR + ETHANOL INTELLIGENCE</p>
          <h2>{shown.length} haber gösteriliyor</h2>
          <p>
            ChiniMandi ve GDELT 15 dakikada bir taranır; her kart doğrudan
            kaynak makaleyi açar.
          </p>
        </div>
        <button onClick={enable}>
          🔔 {alerts ? "BİLDİRİMLER AÇIK" : "BİLDİRİMLERİ AÇ"}
        </button>
      </div>
      <div
        className="newsFilters"
        role="tablist"
        aria-label="Haber kategorileri"
      >
        {filters.map((f) => (
          <button
            type="button"
            role="tab"
            aria-selected={active === f}
            className={active === f ? "active" : ""}
            onClick={() => setActive(f)}
            key={f}
          >
            {active === f ? "● " : ""}
            {f}
          </button>
        ))}
      </div>
      <div className="newsList">
        {shown.length ? (
          shown.map((n, i) => (
            <a
              href={n.url}
              target="_blank"
              rel="noopener noreferrer"
              key={n.url}
              className="newsItem"
            >
              <div className="newsIndex">{String(i + 1).padStart(2, "0")}</div>
              <div>
                <p className="eyebrow">
                  {n.domain} · {n.source} · {n.date?.slice(0, 16)}
                </p>
                <h3>{n.title}</h3>
                <span>{n.category.toUpperCase()}</span>
              </div>
              <b aria-label="Haberi aç">↗</b>
            </a>
          ))
        ) : (
          <article className="card empty">
            <h2>Bu kategoride haber bulunamadı</h2>
            <p>
              Başka bir sekmeyi seçebilir veya otomatik yenilemeyi
              bekleyebilirsin.
            </p>
          </article>
        )}
      </div>
    </>
  );
}
function Ethanol() {
  const parity = [
    ["India Export Parity (MSP + Basis)", 16.02, 0.71],
    ["India Export Parity (Mumbai)", 21.95, -5.22],
    ["China Import Parity BR", 15.15, 1.58],
    ["China Import Parity BR +605 RMB/t", 17.86, -1.13],
    ["Crystal Sugar CEPEA FOB", 17.64, -0.91],
    ["Hydrous · CEPEA Paulínia", 13.42, 3.31],
    ["Hydrous RBOB + CBio", 13.02, 3.71],
    ["Hydrous B3", 14.42, 2.31],
    ["Hydrous B3 + CBio", 14.56, 2.17],
  ];
  return (
    <div className="grid two">
      <article className="card parity">
        <p className="eyebrow">KEY INDICATORS · REFERANS EKRANI</p>
        <h2>Şeker / Etanol Pariteleri</h2>
        <div className="parityHead">
          <b>Gösterge</b>
          <b>US¢/lb</b>
          <b>No.11 Abs Δ</b>
        </div>
        {parity.map((r) => (
          <div className="parityRow" key={String(r[0])}>
            <span>{r[0]}</span>
            <b>{r[1]}</b>
            <i className={(r[2] as number) >= 0 ? "up" : "down"}>
              {(r[2] as number) > 0 ? "+" : ""}
              {r[2]}
            </i>
          </div>
        ))}
        <p className="source">
          Parite ekranındaki değerler
          temsili gösterim verisidir.
        </p>
      </article>
      <article className="card">
        <p className="eyebrow">NASIL OKUNUR?</p>
        <h2>Mill Allocation Dashboard</h2>
        {[
          [
            "Anhydrous Ethanol",
            "Benzine zorunlu harman; talep politika ve benzin tüketimine bağlı.",
          ],
          [
            "Hydrous Ethanol",
            "Flex araçlarda doğrudan yakıt; pompa paritesi kritik.",
          ],
          [
            "Sugar Mix",
            "Kamışın şekere ayrılan payı yükselirse şeker arzı artar.",
          ],
          ["Ethanol Mix", "Etanole ayrılan pay; şeker arzını sınırlar."],
          ["ATR", "Kamıştaki geri kazanılabilir şeker; verim ve gelir tabanı."],
          ["Days Lost", "Yağmur/operasyon nedeniyle kaybedilen crush günü."],
        ].map((r) => (
          <div className="explain" key={r[0]}>
            <b>{r[0]}</b>
            <p>{r[1]}</p>
          </div>
        ))}
      </article>
    </div>
  );
}
function MiniBars({
  values,
  labels,
  color = "#2fb39f",
  zero = false,
}: {
  values: number[];
  labels: string[];
  color?: string;
  zero?: boolean;
}) {
  const max = Math.max(...values.map(Math.abs));
  return (
    <div className={zero ? "miniBars zero" : "miniBars"}>
      {values.map((v, i) => (
        <div key={labels[i]}>
          <span
            className={v < 0 ? "neg" : ""}
            style={{
              height: `${Math.max(5, (Math.abs(v) / max) * 100)}%`,
              background: v < 0 ? "#d71919" : color,
            }}
          >
            <b>{v}</b>
          </span>
          <small>{labels[i]}</small>
        </div>
      ))}
    </div>
  );
}
function SD() {
  const prod = [
      145.5, 156.6, 166.1, 172.1, 170.5, 173.9, 160.3, 166.4, 188.3, 175.8,
      161.2, 172.9, 178.3, 173.9, 180.9, 176.7, 185.3, 178.3, 177,
    ],
    cons = [
      153.1, 154.7, 157.4, 161.3, 164.5, 166.7, 166.9, 167.6, 169.7, 170.9, 169,
      170.9, 174.6, 175.3, 176.5, 177.2, 177.9, 179.2, 179.9,
    ],
    sur = [
      7.2, -6.6, -1.2, 18.6, 4.8, -7.8, 2.1, 3.7, -1.3, 4.4, -0.5, 7.2, -0.9,
      -2.9,
    ],
    yrs = prod.map(
      (_, i) => String(2009 + i).slice(2) + "/" + String(10 + i).slice(-2),
    );
  return (
    <div className="grid chartGrid">
      <article className="card">
        <p className="eyebrow">GLOBAL SUGAR BALANCE</p>
        <h2>Üretim · Million tonnes</h2>
        <MiniBars values={prod} labels={yrs} />
      </article>
      <article className="card">
        <p className="eyebrow">GLOBAL SUGAR BALANCE</p>
        <h2>Tüketim · Million tonnes</h2>
        <MiniBars values={cons} labels={yrs} color="#c8d600" />
      </article>
      <article className="card wide">
        <p className="eyebrow">SURPLUS / DEFICIT</p>
        <h2>Küresel Denge · Million tonnes</h2>
        <MiniBars
          values={sur}
          labels={sur.map(
            (_, i) =>
              String(2014 + i).slice(2) + "/" + String(15 + i).slice(-2),
          )}
          zero
        />
        <p className="source">
          Görsellerdeki CZ çalışma serileri; 2026/27 ve 2027/28 forecast dahil.
        </p>
      </article>
      <Destinations />
    </div>
  );
}
function Destinations() {
  const d = [
    ["China", 4.85],
    ["Algeria", 2.15],
    ["India", 2.7],
    ["Indonesia", 3.45],
    ["Nigeria", 1.75],
    ["Saudi Arabia", 2.05],
    ["Bangladesh", 2],
    ["Morocco", 1.65],
    ["Egypt", 2.2],
    ["Malaysia", 1.7],
    ["Canada", 1.3],
    ["UAE", 2.05],
    ["Iraq", 1.28],
    ["Iran", 0.85],
    ["USA", 0.96],
    ["Black Sea", 0.45],
  ];
  return (
    <article className="card wide">
      <p className="eyebrow">TRADE FLOW</p>
      <h2>Top Destinations · 2024 referans, Mt</h2>
      <div className="destinations">
        {d.map((x) => (
          <div key={x[0]}>
            <span>{x[0]}</span>
            <i>
              <b style={{ width: `${((x[1] as number) / 5) * 100}%` }} />
            </i>
            <strong>{x[1]}M</strong>
          </div>
        ))}
      </div>
    </article>
  );
}
function Brazil() {
  const rows = [
    ["Cane", 214.47, "+3.8%"],
    ["Sugar", 10.754, "−12.4%"],
    ["Anhydrous", 4.12, "+24.6%"],
    ["Hydrous", 7.245, "+18.2%"],
    ["Total Ethanol", 11.365, "+20.4%"],
    ["TRS", 26.542, "+5.2%"],
    ["TRS / Tonne Cane", 123.8, "+1.3%"],
    ["Sugar Mix", 42.5, "−8.5 pp"],
    ["Ethanol Mix", 57.5, "+8.5 pp"],
    ["Ethanol L/t Cane", 41.83, "+19.0%"],
    ["Sugar kg/t Cane", 50.14, "−15.6%"],
  ];
  return (
    <div className="grid two">
      <article className="card wide">
        <p className="eyebrow">UNICA · CENTER-SOUTH CUMULATIVE</p>
        <h2>2026/27 Production Monitor</h2>
        <div className="unica">
          <b>Product</b>
          <b>2026/27</b>
          <b>Delta</b>
          {rows.map((r) => (
            <div className="unicaRow" key={String(r[0])}>
              <span>{r[0]}</span>
              <strong>{r[1]}</strong>
              <i className={String(r[2]).startsWith("+") ? "up" : "down"}>
                {r[2]}
              </i>
            </div>
          ))}
        </div>
        <p className="source">
          Paylaşılan UNICA tablosundan alınan izleme başlıkları; bin ton/milyon
          litre/kg ATR birimleri ürün satırına göre değişir.
        </p>
      </article>
      <article className="card">
        <p className="eyebrow">MILL DECISION</p>
        <h2>Şeker–Etanol Allocation</h2>
        <div
          className="donut"
          style={{
            background: "conic-gradient(#d9ff43 0 42.5%,#2fb39f 42.5% 100%)",
          }}
        >
          <div>
            <b>42.5%</b>
            <span>Sugar mix</span>
          </div>
        </div>
        <div className="mixLegend">
          <span>
            <i />
            Sugar 42.5%
          </span>
          <span>
            <i />
            Ethanol 57.5%
          </span>
        </div>
        <p className="source">
          Sugar mix gerilerken ethanol mix yükselmiş: marjinal şeker arzı
          açısından destekleyici sinyal.
        </p>
      </article>
    </div>
  );
}
function CFTC({ cot }: { cot: Live["cot"] | undefined }) {
  if (!cot)
    return (
      <article className="card empty">
        <h2>CFTC verisi yükleniyor</h2>
      </article>
    );
  const net = cot.moneyLong - cot.moneyShort;
  return (
    <div className="grid two">
      <article className="card">
        <p className="eyebrow">RESMÎ CFTC · {cot.date}</p>
        <h2>Managed Money</h2>
        <div className="heroMetric">
          <span>Net pozisyon</span>
          <b className={net >= 0 ? "up" : "down"}>
            {net.toLocaleString()} kontrat
          </b>
        </div>
        <div className="bars">
          <label>
            Long <b>{cot.moneyLong.toLocaleString()}</b>
          </label>
          <i>
            <span
              style={{
                width: `${(cot.moneyLong / (cot.moneyLong + cot.moneyShort)) * 100}%`,
              }}
            />
          </i>
          <label>
            Short <b>{cot.moneyShort.toLocaleString()}</b>
          </label>
          <i className="short">
            <span
              style={{
                width: `${(cot.moneyShort / (cot.moneyLong + cot.moneyShort)) * 100}%`,
              }}
            />
          </i>
        </div>
      </article>
      <article className="card">
        <p className="eyebrow">COMMERCIALS</p>
        <h2>Producer / Merchant</h2>
        <div className="balance">
          <div>
            <span>Open Interest</span>
            <b>{cot.openInterest.toLocaleString()}</b>
          </div>
          <div>
            <span>Producer Long</span>
            <b>{cot.producerLong.toLocaleString()}</b>
          </div>
          <div>
            <span>Producer Short</span>
            <b>{cot.producerShort.toLocaleString()}</b>
          </div>
        </div>
        <p className="source">CFTC PRE Disaggregated Futures Only.</p>
      </article>
    </div>
  );
}
function Weather({
  weather,
  active,
  setActive,
}: {
  weather: Live["weather"] | undefined;
  active: number;
  setActive: (n: number) => void;
}) {
  if (!weather)
    return (
      <article className="card empty">
        <h2>Hava verisi yükleniyor</h2>
      </article>
    );
  const p = weather[active];
  return (
    <>
      <div className="weatherTabs">
        {weather.map((x, i) => (
          <button
            className={i === active ? "active" : ""}
            onClick={() => setActive(i)}
            key={x.id}
          >
            {x.name}
            <small>{x.stage}</small>
          </button>
        ))}
      </div>
      <article className="card">
        <div className="cardhead">
          <div>
            <p className="eyebrow">OPEN-METEO · 7 GÜN</p>
            <h2>{p.name}</h2>
          </div>
          <Badge live>FORECAST</Badge>
        </div>
        <div className="forecast">
          {p.days.map((d) => (
            <div key={d.date}>
              <span>
                {new Date(d.date).toLocaleDateString("tr-TR", {
                  weekday: "short",
                })}
              </span>
              <b>{d.max}°</b>
              <small>{d.min}° min</small>
              <i>☂ {d.rain} mm</i>
              <em>%{d.prob}</em>
            </div>
          ))}
        </div>
        <p className="source">
          Bölgesel risk ekranıdır; tarla bazlı tahmin değildir.
        </p>
      </article>
    </>
  );
}
function Drivers({ data }: { data: Live | null }) {
  const net = data?.cot ? data.cot.moneyLong - data.cot.moneyShort : 0,
    w =
      data?.weather?.[0]?.days.slice(0, 7).reduce((s, x) => s + x.rain, 0) || 0;
  const d = [
    [
      "Brazil CS crush",
      "214.5 Mt",
      "↑",
      "Cane hacmi güçlü; fakat mix şeker arzını sınırlıyor",
    ],
    [
      "Sugar mix",
      "42.5%",
      "↓",
      "Şeker için bullish: daha az cane şekere gidiyor",
    ],
    [
      "Hydrous / Anhydrous",
      "7.25 / 4.12 bn L",
      "↑",
      "Etanol üretimi allocation rekabetini artırıyor",
    ],
    [
      "BRL",
      data?.fx?.value?.toFixed(3) || "—",
      "●",
      "Güçlü BRL ihracat satışını yavaşlatabilir",
    ],
    [
      "7d Brazil rainfall",
      w.toFixed(1) + " mm",
      w > 30 ? "↑" : "↓",
      w > 30 ? "Crush kesintisi riski" : "Crush için elverişli",
    ],
    [
      "El Niño · Niño 3.4",
      "+2.7°C",
      "↑",
      "Güçlü El Niño: ülke bazlı yağış dağılımı riski",
    ],
    [
      "Managed Money net",
      (net / 1000).toFixed(1) + "K",
      net > 0 ? "↑" : "↓",
      net < 0 ? "Short-covering yakıtı var" : "Long liquidation riski",
    ],
    [
      "Global balance 27/28f",
      "−2.9 Mt",
      "↓",
      "Deficit: stok tamponu daralıyor",
    ],
  ];
  return (
    <div className="drivers">
      {d.map((x, i) => (
        <article className="card" key={x[0]}>
          <p className="eyebrow">DRIVER {String(i + 1).padStart(2, "0")}</p>
          <h2>{x[0]}</h2>
          <b className="driverValue">{x[1]}</b>
          <span className={x[2] === "↑" ? "up" : "down"}>{x[2]}</span>
          <p>{x[3]}</p>
        </article>
      ))}
    </div>
  );
}
function ResearchCalendar() {
  const rows = [
    [
      "Her sabah",
      "Futures, spreads, BRL, oil, CEPEA pariteleri, haberler",
      "ICE/LSEG, ECB, CEPEA, News",
      "08:30",
      "Günlük yön ve overnight risk",
    ],
    [
      "Her gün",
      "Brazil/India/Thailand yağış, sıcaklık, moisture, NDVI, hazards",
      "Open-Meteo, GADAS, JRC/Agri4Cast",
      "09:00",
      "Crush ve yield riski",
    ],
    [
      "Salı kapanış",
      "COT snapshot referans tarihi",
      "CFTC",
      "Haftalık",
      "Fon/commercial pozisyon değişimi",
    ],
    [
      "Cuma",
      "COT yayını ve yorum",
      "CFTC",
      "22:30 TR civarı",
      "Crowding, short-covering, liquidation",
    ],
    [
      "15 günde bir",
      "Cane crush, ATR/TRS, sugar/ethanol mix, production",
      "UNICA / MAPA",
      "Rapor günü",
      "Brazil CS arz hızı",
    ],
    [
      "Aylık",
      "WASDE US/Mexico S&D, stocks/use",
      "USDA",
      "Takvimli",
      "No.16/NAFTA dengesi",
    ],
    [
      "Aylık",
      "India production, mills, diversion, exports",
      "ISMA/NFCSF",
      "Sezon içinde",
      "Exportable surplus",
    ],
    [
      "Aylık",
      "EU beet weather/yield forecast",
      "JRC MARS",
      "Ay sonu",
      "EU white balance",
    ],
    [
      "Aylık",
      "Bilateral imports/exports + destinations",
      "UN Comtrade / customs",
      "Gecikmeli",
      "Gerçekleşen trade flow",
    ],
    [
      "Çeyreklik",
      "Global S&D, trade-flow forecast, 5y outlook",
      "CZ/Green Pool/Hedgepoint",
      "Provider",
      "Stratejik pozisyon",
    ],
    [
      "Olay bazlı",
      "El Niño, frost, fire, cyclone, policy, tariffs",
      "NOAA/GADAS/Govt",
      "Anlık",
      "Tail risk",
    ],
  ];
  return (
    <article className="card">
      <div className="cardhead">
        <div>
          <p className="eyebrow">DESK OPERATING RHYTHM</p>
          <h2>Neyi, Ne Zaman, Nereden Takip Edeceğiz?</h2>
        </div>
        <Badge live>MASTER CHECKLIST</Badge>
      </div>
      <div className="researchTable">
        <b>Sıklık</b>
        <b>Kontrol</b>
        <b>Kaynak</b>
        <b>Saat/Dönem</b>
        <b>Neden?</b>
        {rows.map((r) => (
          <div className="researchTr" key={r[0] + r[1]}>
            {r.map((x, i) =>
              i === 0 ? <strong key={x}>{x}</strong> : <span key={x}>{x}</span>,
            )}
          </div>
        ))}
      </div>
    </article>
  );
}
function RiskTools() {
  const [lot, setLot] = useState(10),
    [entry, setEntry] = useState(16.25),
    [stop, setStop] = useState(15.75),
    [target, setTarget] = useState(17.5),
    [spot, setSpot] = useState(16.84),
    [strike, setStrike] = useState(17),
    [days, setDays] = useState(60),
    [vol, setVol] = useState(28),
    [rate, setRate] = useState(4.5);
  const risk = Math.abs(entry - stop) * 1120 * lot,
    reward = Math.abs(target - entry) * 1120 * lot,
    rr = risk ? reward / risk : 0;
  const N = (x: number) => 1 / (1 + Math.exp(-1.702 * x)),
    t = days / 365,
    v = vol / 100,
    r = rate / 100,
    d1 =
      (Math.log(spot / strike) + (r + (v * v) / 2) * t) /
      (v * Math.sqrt(t) || 1),
    d2 = d1 - v * Math.sqrt(t),
    call = spot * N(d1) - strike * Math.exp(-r * t) * N(d2),
    put = strike * Math.exp(-r * t) * N(-d2) - spot * N(-d1);
  return (
    <div className="grid two">
      <article className="card">
        <p className="eyebrow">POSITION RISK</p>
        <h2>Stop, Target ve R:R</h2>
        <div className="form">
          <label>
            Lot
            <input
              type="number"
              value={lot}
              onChange={(e) => setLot(+e.target.value)}
            />
          </label>
          <label>
            Entry
            <input
              type="number"
              step=".01"
              value={entry}
              onChange={(e) => setEntry(+e.target.value)}
            />
          </label>
          <label>
            Stop
            <input
              type="number"
              step=".01"
              value={stop}
              onChange={(e) => setStop(+e.target.value)}
            />
          </label>
          <label>
            Target
            <input
              type="number"
              step=".01"
              value={target}
              onChange={(e) => setTarget(+e.target.value)}
            />
          </label>
        </div>
        <div className="riskResult">
          <div>
            <span>Stop olursan</span>
            <b className="down">−${risk.toLocaleString()}</b>
          </div>
          <div>
            <span>Hedefe giderse</span>
            <b className="up">+${reward.toLocaleString()}</b>
          </div>
          <div>
            <span>Risk : Reward</span>
            <b>1 : {rr.toFixed(2)}</b>
          </div>
        </div>
      </article>
      <article className="card">
        <p className="eyebrow">BLACK-76 STYLE EDUCATIONAL ESTIMATE</p>
        <h2>Opsiyon Prim Hesaplayıcı</h2>
        <div className="form">
          <label>
            Futures
            <input
              type="number"
              step=".01"
              value={spot}
              onChange={(e) => setSpot(+e.target.value)}
            />
          </label>
          <label>
            Strike
            <input
              type="number"
              step=".01"
              value={strike}
              onChange={(e) => setStrike(+e.target.value)}
            />
          </label>
          <label>
            Days
            <input
              type="number"
              value={days}
              onChange={(e) => setDays(+e.target.value)}
            />
          </label>
          <label>
            IV %
            <input
              type="number"
              value={vol}
              onChange={(e) => setVol(+e.target.value)}
            />
          </label>
          <label>
            Rate %
            <input
              type="number"
              value={rate}
              onChange={(e) => setRate(+e.target.value)}
            />
          </label>
        </div>
        <div className="riskResult">
          <div>
            <span>Call premium</span>
            <b>{call.toFixed(3)} ¢/lb</b>
            <small>${(call * 1120).toFixed(0)}/lot</small>
          </div>
          <div>
            <span>Put premium</span>
            <b>{put.toFixed(3)} ¢/lb</b>
            <small>${(put * 1120).toFixed(0)}/lot</small>
          </div>
          <div>
            <span>ATM straddle</span>
            <b>{(call + put).toFixed(3)} ¢/lb</b>
          </div>
        </div>
        <p className="source">
          Eğitim tahminidir; gerçek ICE option settlement, skew ve American
          exercise farklarını içermez.
        </p>
      </article>
      <PhysicalBoard />
    </div>
  );
}
function PhysicalBoard() {
  const rows = [
    ["Brazil VHP", "Santos", "NY11 +42", "FOB", "Input"],
    ["Brazil IC45", "Santos", "#5 +28", "FOB", "Input"],
    ["Thailand Hi-Pol", "Laem Chabang", "#5 +35", "FOB", "Input"],
    ["India Plantation White", "Mundra", "#5 +22", "FOB", "Policy-sensitive"],
    ["EU White", "North Europe", "#5 +55", "Delivered", "Platts/Fastmarkets"],
    ["China Import Parity", "Brazil origin", "15.15 ¢/lb", "Parity", "Model"],
  ];
  return (
    <article className="card wide">
      <p className="eyebrow">PHYSICAL MARKET BOARD</p>
      <h2>Premiums, FOB Basis ve Pariteler</h2>
      <div className="physicalTable">
        <b>Product</b>
        <b>Port/Market</b>
        <b>Basis</b>
        <b>Incoterm</b>
        <b>Status</b>
        {rows.map((r) => (
          <div className="physicalTr" key={r[0]}>
            {r.map((x) => (
              <span key={x}>{x}</span>
            ))}
          </div>
        ))}
      </div>
    </article>
  );
}
function SourceCatalog() {
  const rows = [
    [
      "Open-Meteo",
      "Rainfall, temp, forecast",
      "API · 30 min",
      "Automatic",
      "Free",
    ],
    [
      "CFTC PRE",
      "Managed Money, producer, OI",
      "API · weekly",
      "Automatic",
      "Free",
    ],
    [
      "ECB/Frankfurter",
      "USD/BRL reference",
      "API · daily",
      "Automatic",
      "Free",
    ],
    [
      "GDELT",
      "Current + historical news archive",
      "API · 15 min",
      "Automatic",
      "Free",
    ],
    [
      "NOAA CPC",
      "Niño 3.4/RONI, ENSO outlook",
      "Monthly/weekly",
      "Connector planned",
      "Free",
    ],
    [
      "USDA GADAS",
      "Weather, hazards, SMAP moisture anomaly, satellite imagery",
      "Near real time",
      "Deep-link/layer connector",
      "Free",
    ],
    [
      "JRC MARS Atlas",
      "Agromet indicators, crop conditions, yield outlook",
      "Monthly/NRT",
      "Connector planned",
      "Free",
    ],
    [
      "Agri4Cast Toolbox",
      "Weather, crop model, EO, bulletin archive since 2007",
      "Monthly/data files",
      "Download/ETL",
      "Free",
    ],
    [
      "UNICA/MAPA",
      "Cane, ATR/TRS, mix, sugar/ethanol production",
      "Fortnightly",
      "PDF/Excel import",
      "Free/manual",
    ],
    [
      "ISMA/NFCSF",
      "India production, diversion, mills",
      "Seasonal updates",
      "Manual/provider",
      "Mixed",
    ],
    [
      "WASDE/USDA PSD",
      "Production, consumption, imports, exports, stocks",
      "Monthly",
      "API/download planned",
      "Free",
    ],
    [
      "UN Comtrade",
      "Bilateral import/export, destinations",
      "Monthly lag",
      "API planned",
      "Free key",
    ],
    [
      "Green Pool",
      "Sugar/biofuels weather, arbs, parities, flows, balances",
      "Daily-weekly-quarterly",
      "Subscription",
      "Licensed",
    ],
    [
      "CZ App",
      "Price forecast, trade flow, order flow, hedge update, Statshot",
      "Weekly/monthly",
      "Subscription",
      "Licensed",
    ],
    [
      "Hedgepoint HUB",
      "Market indicators, analysis, meetings, macro/energy",
      "Multiple",
      "Subscription",
      "Licensed",
    ],
    [
      "ICE/LSEG/Bloomberg",
      "Futures, options, settlements, realtime news",
      "Real time",
      "Enterprise API",
      "Licensed",
    ],
  ];
  return (
    <article className="card">
      <p className="eyebrow">DATA LINEAGE</p>
      <h2>Hangi Veriyi Nereden Çekiyoruz?</h2>
      <div className="sourceTable">
        <b>Kaynak</b>
        <b>Veri</b>
        <b>Sıklık</b>
        <b>Bağlantı</b>
        <b>Lisans</b>
        {rows.map((r) => (
          <div className="sourceTr" key={r[0]}>
            {r.map((x, i) =>
              i === 0 ? <strong key={x}>{x}</strong> : <span key={x}>{x}</span>,
            )}
          </div>
        ))}
      </div>
    </article>
  );
}
function CropConditions({ weather }: { weather: Live["weather"] | undefined }) {
  const soil = [32, 58, 67],
    ndvi = [0.71, 0.76, 0.69],
    names = ["Brazil CS", "Maharashtra", "Khon Kaen"];
  return (
    <>
      <div className="enso">
        <div>
          <p className="eyebrow">NOAA ENSO MONITOR</p>
          <h2>Güçlü El Niño koşulları</h2>
          <b>Niño 3.4: +2.7°C</b>
          <span>12 Ağustos 2026 haftası</span>
        </div>
        <div className="ensoScale">
          <i />
          <b>La Niña</b>
          <b>Neutral</b>
          <b>El Niño</b>
        </div>
      </div>
      <div className="grid chartGrid">
        {names.map((n, i) => {
          const rain = weather?.[i]?.days.reduce((s, x) => s + x.rain, 0) || 0,
            temp =
              weather?.[i]?.days.reduce((s, x) => s + x.max, 0) /
                (weather?.[i]?.days.length || 1) || 0;
          return (
            <article className="card crop" key={n}>
              <p className="eyebrow">CROP CONDITION</p>
              <h2>{n}</h2>
              <div className="conditionScore">{i === 0 ? "WATCH" : "GOOD"}</div>
              {[
                ["Soil moisture", soil[i] + "%"],
                ["NDVI proxy", ndvi[i]],
                ["7d rainfall", rain.toFixed(1) + " mm"],
                ["Avg max temp", temp.toFixed(1) + "°C"],
              ].map((r) => (
                <div className="health" key={r[0]}>
                  <span>{r[0]}</span>
                  <b>{r[1]}</b>
                </div>
              ))}
              <p className="source">
                Moisture/NDVI şimdilik izleme şablonu; Copernicus connector
                eklendiğinde otomatikleşir.
              </p>
            </article>
          );
        })}
      </div>
    </>
  );
}
function TradeFlows() {
  const flows = [
      ["Brazil", "China", 4.85, "VHP / Raw"],
      ["Brazil", "Algeria", 2.15, "Raw / White"],
      ["Thailand", "Indonesia", 1.97, "Raw / Hi-Pol"],
      ["India", "Bangladesh", 1.12, "White / Raw"],
      ["Brazil", "Indonesia", 3.45, "VHP"],
      ["Thailand", "China", 0.86, "Raw"],
    ],
    stats = [
      ["Brazil", 44.7, 34.8, 0.3],
      ["Thailand", 11.2, 7.8, 0.4],
      ["India", 32, 1.5, 0.6],
      ["China", 11.4, 0.1, 6.2],
    ];
  return (
    <>
      <article className="card flowMap">
        <p className="eyebrow">ORIGIN → DESTINATION</p>
        <h2>Global Sugar Trade Lanes</h2>
        <div className="flowWorld">
          <span className="pin br">Brazil</span>
          <span className="pin in">India</span>
          <span className="pin th">Thailand</span>
          <span className="pin cn">China</span>
          <i className="lane l1" />
          <i className="lane l2" />
          <i className="lane l3" />
        </div>
        <div className="flowRows">
          {flows.map((x) => (
            <div key={x[0] + x[1]}>
              <b>{x[0]}</b>
              <strong>→</strong>
              <b>{x[1]}</b>
              <span>{x[2]} Mt</span>
              <i>{x[3]}</i>
            </div>
          ))}
        </div>
      </article>
      <article className="card">
        <p className="eyebrow">IMPORT / EXPORT PROFILE · MT</p>
        <h2>China · Thailand · India · Brazil</h2>
        <div className="flowTable">
          <b>Country</b>
          <b>Production</b>
          <b>Exports</b>
          <b>Imports</b>
          <b>Export/Prod.</b>
          {stats.map((x) => (
            <div className="flowTr" key={x[0]}>
              <strong>{x[0]}</strong>
              <span>{x[1]}</span>
              <span>{x[2]}</span>
              <span>{x[3]}</span>
              <i>{(((x[2] as number) / (x[1] as number)) * 100).toFixed(0)}%</i>
            </div>
          ))}
        </div>
        <p className="source">
          Çalışma tahmini. Historical customs otomasyonu: UN Comtrade; real-time
          lineups: kurumsal provider.
        </p>
      </article>
    </>
  );
}
function DataHub() {
  const [rows, setRows] = useState<number[][]>([]),
    [stamp, setStamp] = useState("");
  useEffect(() => {
    try {
      setRows(JSON.parse(localStorage.getItem("sugarflow-custom") || "[]"));
      setStamp(localStorage.getItem("sugarflow-custom-date") || "");
    } catch {}
  }, []);
  const upload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => {
      const parsed = String(r.result)
        .split(/\r?\n/)
        .slice(1)
        .map((x) => x.split(/[,;]/).map(Number))
        .filter((x) => x.length > 1 && x.every(Number.isFinite));
      const now = new Date().toISOString();
      setRows(parsed);
      setStamp(now);
      localStorage.setItem("sugarflow-custom", JSON.stringify(parsed));
      localStorage.setItem("sugarflow-custom-date", now);
    };
    r.readAsText(f);
  };
  return (
    <div className="grid two">
      <article className="card upload">
        <p className="eyebrow">SELF-SERVICE DATA</p>
        <h2>CSV Yükle → Grafik Anında Güncellensin</h2>
        <p>
          İlk satır başlık; sonraki satırlarda dönem ve sayısal değerler olmalı.
        </p>
        <label>
          ＋ CSV SEÇ
          <input type="file" accept=".csv" onChange={upload} />
        </label>
        <small>
          {rows.length
            ? `${rows.length} satır yüklendi · ${stamp.slice(0, 16).replace("T", " ")}`
            : "Henüz dosya yüklenmedi"}
        </small>
      </article>
      <article className="card">
        <p className="eyebrow">LIVE CUSTOM CHART</p>
        <h2>Yüklenen Seri</h2>
        {rows.length ? (
          <MiniBars
            values={rows.slice(-20).map((x) => x[1])}
            labels={rows.slice(-20).map((x) => String(x[0]))}
          />
        ) : (
          <div className="empty">CSV yüklendiğinde grafik burada oluşacak.</div>
        )}
      </article>
      <article className="card wide architecture">
        <h2>Power BI mantığı bu sitede nasıl çalışır?</h2>
        <div>
          <span>Excel / API / PDF</span>
          <b>→</b>
          <span>Merkezi veritabanı</span>
          <b>→</b>
          <span>Grafikler + yorum</span>
          <b>→</b>
          <span>Bildirim</span>
        </div>
        <p>
          Bu sürümde CSV, bulunduğun cihazda anında güncellenir. Desk genelinde
          herkesin aynı veriyi görmesi için bir sonraki teknik adım D1/Supabase
          + zamanlanmış ETL’dir.
        </p>
      </article>
    </div>
  );
}
function Licenses() {
  const rows = [
    [
      "ICE Futures U.S./Europe",
      "NY #11, London #5 real-time, OI, volume",
      "ICE Data / vendor",
      "Published legacy reference: API $2,000/month; current quote required",
    ],
    [
      "Bloomberg SAPI / B-PIPE",
      "Futures, FX, news, third-party data",
      "Bloomberg Enterprise Data",
      "Quote required; Terminal Desktop API server use için yeterli değil",
    ],
    [
      "LSEG Data Platform",
      "Futures, CEPEA/LSEC curves, news",
      "LSEG Sales + content entitlements",
      "Premium; quote required",
    ],
    [
      "S&P Global Platts",
      "FOB assessments, physical sugar, history",
      "Commodity Insights API",
      "Quote required",
    ],
    [
      "CEPEA/ESALQ",
      "Paulínia hydrous, crystal sugar indices",
      "CEPEA redistribution/API permission",
      "Public viewing olabilir; automated redistribution permission required",
    ],
    [
      "Kpler Agri & Biofuels",
      "Cargo flows, ports, buyers/sellers, forecasts",
      "Kpler enterprise/API",
      "Quote/demo required",
    ],
    [
      "Vessel/Port Lineups",
      "Vessel nominations, load/discharge, queues",
      "Kpler / AXSMarine / Veson",
      "Quote required",
    ],
    [
      "CZ / Dnext / Hedgepoint",
      "Cane, ATR, mix, balances, forecasts",
      "Provider enterprise agreement",
      "Quote required; dashboard redistribution ayrıca sorulmalı",
    ],
    [
      "UN Comtrade",
      "Monthly/annual bilateral imports/exports",
      "UN Comtrade API",
      "Free key: up to 500 calls/day; premium terms vary",
    ],
    [
      "Copernicus",
      "Soil moisture, NDVI/satellite layers",
      "CDSE/openEO",
      "Free tier: 10,000 credits/month",
    ],
    [
      "NOAA + CFTC + USDA",
      "ENSO, COT, WASDE/PSD",
      "Public APIs/downloads",
      "Free",
    ],
  ];
  return (
    <article className="card">
      <p className="eyebrow">DATA PROCUREMENT</p>
      <h2>Lisans ve API Matrisi</h2>
      <div className="licenseTable">
        <b>Provider</b>
        <b>Ne için?</b>
        <b>Nereden?</b>
        <b>Fiyat / durum</b>
        {rows.map((r) => (
          <div className="licenseTr" key={r[0]}>
            <strong>{r[0]}</strong>
            <span>{r[1]}</span>
            <span>{r[2]}</span>
            <i>{r[3]}</i>
          </div>
        ))}
      </div>
      <p className="source">
        Kamuya açık fiyat bulunmayan ürünlerde rakam uydurulmadı; kurumsal
        teklif gerekir. ICE $2,000 değeri 2021 fee overview referansıdır, güncel
        teklif değildir.
      </p>
    </article>
  );
}
function Calendar() {
  const rows = [
    {
      n: "Brazil CS",
      p: [9, 10, 11, 12, 1, 2, 3, 4],
      h: [3, 4, 5, 6, 7, 8, 9, 10, 11],
    },
    {
      n: "Brazil NNE",
      p: [3, 4, 5, 6, 7, 8],
      h: [7, 8, 9, 10, 11, 12, 1, 2, 3],
    },
    { n: "India", p: [10, 11, 12, 1, 2, 3], h: [10, 11, 12, 1, 2, 3, 4] },
    { n: "Thailand", p: [5, 6, 7, 8, 9, 10], h: [11, 12, 1, 2, 3, 4] },
    { n: "EU Beet", p: [3, 4, 5], h: [9, 10, 11, 12] },
  ];
  return (
    <article className="card">
      <p className="eyebrow">GLOBAL CROP CALENDAR</p>
      <h2>Planting & Harvest</h2>
      <div className="calendar">
        <b>Origin</b>
        {[
          "Oca",
          "Şub",
          "Mar",
          "Nis",
          "May",
          "Haz",
          "Tem",
          "Ağu",
          "Eyl",
          "Eki",
          "Kas",
          "Ara",
        ].map((x) => (
          <b key={x}>{x}</b>
        ))}
        {rows.map((r) => (
          <div className="calrow" key={r.n}>
            <strong>{r.n}</strong>
            {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
              <span
                key={m}
                className={
                  r.h.includes(m) ? "harv" : r.p.includes(m) ? "plant" : ""
                }
              >
                {r.h.includes(m) ? "H" : r.p.includes(m) ? "P" : ""}
              </span>
            ))}
          </div>
        ))}
      </div>
      <div className="legend">
        <i className="plant" /> Planting <i className="harv" /> Harvest / Crush
      </div>
    </article>
  );
}
function Lab(p: any) {
  return (
    <div className="grid two">
      <article className="card">
        <div className="cardhead">
          <div>
            <p className="eyebrow">NY #11 P&L</p>
            <h2>Kontrat Hesaplayıcı</h2>
          </div>
          <button
            className="toggle"
            onClick={() => p.setSide(p.side === "LONG" ? "SHORT" : "LONG")}
          >
            {p.side}
          </button>
        </div>
        <div className="form">
          <label>
            Lot
            <input
              type="number"
              value={p.lots}
              onChange={(e) => p.setLots(+e.target.value)}
            />
          </label>
          <label>
            Giriş (¢/lb)
            <input
              type="number"
              step=".01"
              value={p.entry}
              onChange={(e) => p.setEntry(+e.target.value)}
            />
          </label>
          <label>
            Hedef (¢/lb)
            <input
              type="number"
              step=".01"
              value={p.target}
              onChange={(e) => p.setTarget(+e.target.value)}
            />
          </label>
        </div>
        <div className="result">
          <span>
            Tahmini P&L<small>Fark × $1,120 × lot</small>
          </span>
          <b className={p.pnl >= 0 ? "up" : "down"}>
            {p.pnl >= 0 ? "+" : "−"}$
            {Math.abs(p.pnl).toLocaleString("en-US", {
              maximumFractionDigits: 0,
            })}
          </b>
        </div>
      </article>
      <article className="card">
        <p className="eyebrow">DÖNÜŞÜM REHBERİ</p>
        <h2>Şeker Matematiği</h2>
        {[
          ["1 lot NY #11", "112,000 lb"],
          ["1.00 ¢/lb hareket", "$1,120 / lot"],
          ["¢/lb → USD/MT", "× 22.0462"],
          ["USD/MT → ¢/lb", "÷ 22.0462"],
        ].map((r) => (
          <div className="detailrow static" key={r[0]}>
            <span>{r[0]}</span>
            <b>{r[1]}</b>
          </div>
        ))}
      </article>
    </div>
  );
}
