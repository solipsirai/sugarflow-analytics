"use client";
import { useMemo, useState } from "react";

type Row = {
  country: string;
  agency: string;
  method: string;
  cadence: string;
  url: string;
  status: "API" | "Parser" | "Review";
  area?: number;
  yield?: number;
  production?: number;
  stocks?: number;
  exports?: number;
  wow?: number;
  yoy?: number;
};
const sources: Row[] = [
  {
    country: "ABD",
    agency: "USDA NASS Quick Stats",
    method: "API",
    cadence: "Pzt 16:00 ET",
    url: "https://www.nass.usda.gov/Quick_Stats/",
    status: "API",
    area: 12932,
    yield: 3.22,
    production: 41658,
    stocks: 19513,
    exports: 21092,
    wow: -0.3,
    yoy: -7.4,
  },
  {
    country: "Dünya",
    agency: "USDA FAS PSD Online",
    method: "API",
    cadence: "Aylık · WASDE",
    url: "https://apps.fas.usda.gov/psdonline/",
    status: "API",
    area: 225620,
    yield: 3.63,
    production: 819300,
    stocks: 273250,
    exports: 216000,
    wow: -0.1,
    yoy: 1.2,
  },
  {
    country: "Kanada",
    agency: "Statistics Canada · 32-10-0359",
    method: "API",
    cadence: "Tem/Ağu/Eyl/Ara",
    url: "https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=3210035901",
    status: "API",
  },
  {
    country: "Kanada · SK/AB/MB",
    agency: "Provincial Crop Reports",
    method: "PDF/HTML",
    cadence: "Haftalık",
    url: "https://www.saskatchewan.ca/crop-report",
    status: "Parser",
  },
  {
    country: "Rusya",
    agency: "Минсельхоз РФ",
    method: "Bülten",
    cadence: "Haftada 2–3",
    url: "https://mcx.gov.ru/",
    status: "Parser",
  },
  {
    country: "Ukrayna",
    agency: "Мінагрополітики",
    method: "Operativ",
    cadence: "Haftalık",
    url: "https://minagro.gov.ua/",
    status: "Parser",
  },
  {
    country: "AB",
    agency: "Eurostat · apro_cpsh1",
    method: "API",
    cadence: "Aylık",
    url: "https://ec.europa.eu/eurostat/databrowser/product/view/apro_cpsh1",
    status: "API",
  },
  {
    country: "AB · Crop",
    agency: "JRC MARS Bulletin",
    method: "PDF",
    cadence: "Ayın ~20'si",
    url: "https://joint-research-centre.ec.europa.eu/monitoring-agricultural-resources-mars/jrc-mars-bulletin_en",
    status: "Parser",
  },
  {
    country: "Arjantin",
    agency: "Bolsa de Cereales · PAS",
    method: "Bülten",
    cadence: "Perşembe",
    url: "https://www.bolsadecereales.com/",
    status: "Parser",
  },
  {
    country: "Avustralya",
    agency: "ABARES Crop Report",
    method: "PDF/XLSX",
    cadence: "Çeyreklik",
    url: "https://www.agriculture.gov.au/abares/research-topics/agricultural-outlook/australian-crop-report",
    status: "Parser",
  },
  {
    country: "Brezilya",
    agency: "CONAB Safra / Progresso",
    method: "HTML/XLSX",
    cadence: "Haftalık + aylık",
    url: "https://www.gov.br/conab/pt-br/atuacao/informacoes-agropecuarias/safras/progresso-de-safra",
    status: "Parser",
  },
  {
    country: "Hindistan",
    agency: "Dept. of Agriculture",
    method: "Bülten",
    cadence: "Rabi'de haftalık",
    url: "https://agriwelfare.gov.in/",
    status: "Parser",
  },
  {
    country: "Çin",
    agency: "国家统计局 NBS",
    method: "Bülten",
    cadence: "Temmuz",
    url: "https://www.stats.gov.cn/english/",
    status: "Parser",
  },
  {
    country: "Türkiye",
    agency: "TÜİK Bitkisel Üretim",
    method: "Portal",
    cadence: "Tem/Eki/Ara",
    url: "https://data.tuik.gov.tr/",
    status: "Review",
  },
  {
    country: "Kazakistan",
    agency: "Bureau of National Statistics",
    method: "Bülten",
    cadence: "Haftalık · Ağu–Eki",
    url: "https://stat.gov.kz/en/",
    status: "Parser",
  },
  {
    country: "İngiltere",
    agency: "Defra / AHDB",
    method: "HTML/PDF",
    cadence: "Hasatta haftalık",
    url: "https://ahdb.org.uk/cereals-oilseeds/harvest-results",
    status: "Parser",
  },
];
const tabs = [
  "Genel bakış",
  "Ürün takvimi",
  "Hasat edilen alan",
  "Üretim ilerlemesi",
  "Verim ilerlemesi",
  "Hasat ilerlemesi",
  "Ürün koşulu",
  "Sezon dengesi",
];
const regs = [
  ["Kansas", "HRW", 91, 62],
  ["Oklahoma", "HRW", 96, 55],
  ["Texas", "HRW", 98, 53],
  ["North Dakota", "HRS", 55, 59],
  ["Minnesota", "HRS", 48, 62],
  ["Washington", "White", 62, 69],
] as const;
const cal = [
  {
    name: "ABD · HRW (winter)",
    p: [9, 10],
    g: [11, 12, 1, 2, 3, 4],
    h: [5, 6, 7],
  },
  { name: "ABD · HRS (spring)", p: [4, 5], g: [5, 6, 7, 8], h: [8, 9] },
  { name: "Kanada · spring", p: [4, 5], g: [5, 6, 7, 8], h: [8, 9, 10] },
  {
    name: "Kanada · winter",
    p: [9, 10],
    g: [11, 12, 1, 2, 3, 4, 5, 6],
    h: [7, 8],
  },
  {
    name: "Rusya · winter (major)",
    p: [8, 9, 10],
    g: [11, 12, 1, 2, 3, 4, 5, 6],
    h: [7, 8],
  },
  { name: "Rusya · spring", p: [4, 5], g: [5, 6, 7, 8], h: [8, 9] },
  {
    name: "Ukrayna · winter (major)",
    p: [9, 10, 11],
    g: [12, 1, 2, 3, 4, 5, 6],
    h: [7, 8],
  },
  { name: "Ukrayna · spring", p: [3, 4], g: [4, 5, 6], h: [7, 8] },
  {
    name: "AB · winter (major)",
    p: [9, 10, 11],
    g: [12, 1, 2, 3, 4, 5, 6],
    h: [6, 7, 8],
  },
  { name: "AB · spring", p: [2, 3, 4], g: [4, 5, 6, 7], h: [7, 8, 9] },
  { name: "Arjantin", p: [5, 6, 7], g: [7, 8, 9, 10, 11], h: [11, 12, 1] },
  { name: "Avustralya", p: [4, 5, 6], g: [6, 7, 8, 9, 10], h: [10, 11, 12, 1] },
  { name: "Brezilya", p: [4, 5, 6, 7, 8], g: [6, 7, 8, 9], h: [9, 10, 11] },
  { name: "Hindistan · rabi", p: [11, 12], g: [12, 1, 2, 3], h: [3, 4] },
  {
    name: "Çin · winter (major)",
    p: [9, 10, 11],
    g: [12, 1, 2, 3, 4, 5],
    h: [5, 6],
  },
  { name: "Çin · spring", p: [3, 4], g: [4, 5, 6, 7], h: [7, 8] },
  {
    name: "Türkiye · winter (major)",
    p: [10, 11, 12],
    g: [1, 2, 3, 4, 5, 6],
    h: [6, 7, 8],
  },
  { name: "Türkiye · spring", p: [3, 4], g: [4, 5, 6, 7], h: [8, 9] },
  {
    name: "Kazakistan · spring (major)",
    p: [4, 5],
    g: [5, 6, 7, 8],
    h: [8, 9, 10],
  },
  {
    name: "Kazakistan · winter",
    p: [9, 10],
    g: [11, 12, 1, 2, 3, 4, 5, 6],
    h: [7, 8],
  },
  {
    name: "İngiltere · winter (major)",
    p: [9, 10, 11],
    g: [12, 1, 2, 3, 4, 5, 6, 7],
    h: [7, 8, 9],
  },
  { name: "İngiltere · spring", p: [2, 3, 4], g: [4, 5, 6, 7, 8], h: [8, 9] },
];
const f = (n?: number) =>
  n == null ? "—" : n.toLocaleString("en-US", { maximumFractionDigits: 2 });
export function WheatOfficialMonitor() {
  const [tab, setTab] = useState(tabs[0]);
  const [sort, setSort] = useState("value");
  const rows = useMemo(
    () =>
      [...sources].sort((a, b) =>
        sort === "country"
          ? a.country.localeCompare(b.country)
          : (b.production || -1) - (a.production || -1),
      ),
    [sort],
  );
  return (
    <div className="officialMonitor">
      <article className="card monitorHero">
        <div>
          <p className="eyebrow">OFFICIAL-FIRST · WHEAT CROP MONITOR</p>
          <h2>Country → Region → Stage → Balance</h2>
          <p>
            Her ülkenin kendi kurumuna bağlı veri hattı. Doğrulanmamış alanlarda
            rakam üretilmez; “—” gösterilir.
          </p>
        </div>
        <div className="monitorStats">
          <b>
            {sources.length}
            <small>source lanes</small>
          </b>
          <b>
            {sources.filter((x) => x.status === "API").length}
            <small>API lanes</small>
          </b>
          <b>
            {new Date().toLocaleDateString("tr-TR")}
            <small>today</small>
          </b>
        </div>
      </article>
      <nav className="monitorTabs">
        {tabs.map((x) => (
          <button
            key={x}
            className={tab === x ? "active" : ""}
            onClick={() => setTab(x)}
          >
            {x}
          </button>
        ))}
      </nav>
      {tab === "Genel bakış" && (
        <>
          <div className="countryCards">
            {sources
              .filter((x) => x.area)
              .map((c) => (
                <article className="card countryCard" key={c.country}>
                  <p className="eyebrow">{c.agency}</p>
                  <h3>{c.country}</h3>
                  <div className="fiveMetrics">
                    {[
                      ["Alan", f(c.area), "kha"],
                      ["Verim", f(c.yield), "t/ha"],
                      ["Üretim", f(c.production), "kt"],
                      ["Stok", f(c.stocks), "kt"],
                      ["İhracat", f(c.exports), "kt"],
                    ].map((x) => (
                      <span key={x[0]}>
                        <small>{x[0]}</small>
                        <b>{x[1]}</b>
                        <i>{x[2]}</i>
                      </span>
                    ))}
                  </div>
                  <div className="compareStrip">
                    <span>
                      Önceki yayın <b>{c.wow}%</b>
                    </span>
                    <span>
                      Geçen yıl <b>{c.yoy}%</b>
                    </span>
                  </div>
                  <a href={c.url} target="_blank" rel="noreferrer">
                    Resmî kaynağı aç ↗
                  </a>
                </article>
              ))}
          </div>
          <Registry />
        </>
      )}
      {tab === "Ürün takvimi" && <Calendar />}
      {["Hasat edilen alan", "Üretim ilerlemesi", "Verim ilerlemesi"].includes(
        tab,
      ) && <Table tab={tab} rows={rows} setSort={setSort} />}
      {tab === "Hasat ilerlemesi" && <Progress />}
      {tab === "Ürün koşulu" && <Condition />}
      {tab === "Sezon dengesi" && <Balance />}
    </div>
  );
}
function Registry() {
  return (
    <article className="card registry">
      <p className="eyebrow">SOURCE COVERAGE</p>
      <h2>Country-owned official sources</h2>
      <div className="regHead">
        <b>Ülke</b>
        <b>Kurum</b>
        <b>Yöntem</b>
        <b>Sıklık</b>
        <b>Durum</b>
      </div>
      {sources.map((c) => (
        <a
          className="regRow"
          href={c.url}
          target="_blank"
          rel="noreferrer"
          key={c.country}
        >
          <strong>{c.country}</strong>
          <span>{c.agency}</span>
          <span>{c.method}</span>
          <span>{c.cadence}</span>
          <i className={c.status === "API" ? "connected" : "adapter"}>
            {c.status}
          </i>
        </a>
      ))}
    </article>
  );
}
function Calendar() {
  const n = new Date(),
    left = `calc(150px + (100% - 150px) * ${(n.getMonth() + (n.getDate() - 1) / new Date(n.getFullYear(), n.getMonth() + 1, 0).getDate()) / 12})`;
  return (
    <article className="card">
      <p className="eyebrow">GLOBAL WHEAT CROP CALENDAR</p>
      <h2>Planting → Development → Harvest</h2>
      <div className="calendarScroll">
        <div className="ocGrid">
          <div className="ocToday" style={{ left }}>
            <b>
              {n.toLocaleDateString("tr-TR", {
                day: "2-digit",
                month: "short",
              })}
            </b>
          </div>
          <b>Origin</b>
          {[
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec",
          ].map((x) => (
            <b key={x}>{x}</b>
          ))}
          {cal.map((row) => (
            <div className="ocRow" key={row.name}>
              <strong>{row.name}</strong>
              {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => {
                const cls = row.h.includes(m)
                  ? "harvest"
                  : row.p.includes(m)
                    ? "plant"
                    : row.g.includes(m)
                      ? "grow"
                      : "";
                return (
                  <span className={cls} key={m}>
                    {cls === "plant"
                      ? "P"
                      : cls === "harvest"
                        ? "H"
                        : cls === "grow"
                          ? "G"
                          : ""}
                  </span>
                );
              })}
            </div>
          ))}
        </div>
      </div>
      <div className="calendarLegend">
        <span>
          <i className="plant" />
          Planting window
        </span>
        <span>
          <i className="grow" />
          Development
        </span>
        <span>
          <i className="harvest" />
          Harvest window
        </span>
      </div>
      <p className="source">
        Desk windows are ranges, not single dates. Winter and spring wheat are
        split where both systems materially affect production; regional timing
        can shift with weather.
      </p>
    </article>
  );
}
function Table({
  tab,
  rows,
  setSort,
}: {
  tab: string;
  rows: Row[];
  setSort: (x: string) => void;
}) {
  const field = tab.startsWith("Hasat")
      ? "area"
      : tab.startsWith("Üretim")
        ? "production"
        : "yield",
    unit =
      field === "area"
        ? "1,000 ha"
        : field === "production"
          ? "1,000 t"
          : "t/ha";
  return (
    <article className="card tableScroll">
      <div className="cardhead">
        <h2>{tab}</h2>
        <span>{unit}</span>
      </div>
      <div className="otHead">
        <button onClick={() => setSort("country")}>Country ↕</button>
        <b>Agency</b>
        <button onClick={() => setSort("value")}>Value ↕</button>
        <b>WoW</b>
        <b>YoY</b>
        <b>Status</b>
      </div>
      {rows.map((c) => (
        <div className="otRow" key={c.country}>
          <strong>{c.country}</strong>
          <span>{c.agency}</span>
          <b>{f(c[field as keyof Row] as number | undefined)}</b>
          <i>{c.wow == null ? "—" : `${c.wow}%`}</i>
          <i>{c.yoy == null ? "—" : `${c.yoy}%`}</i>
          <em>
            {c[field as keyof Row] == null ? "Parser bekliyor" : "Official"}
          </em>
        </div>
      ))}
    </article>
  );
}
function Progress() {
  return (
    <article className="card">
      <p className="eyebrow">STATE / REGION HARVEST</p>
      <h2>Current vs five-year average</h2>
      <div className="progressRows">
        {regs.map((r) => (
          <div key={r[0]}>
            <span>
              <b>{r[0]}</b>
              <small>{r[1]}</small>
            </span>
            <div>
              <i style={{ width: `${r[2]}%` }} />
            </div>
            <strong>{r[2]}%</strong>
            <em>+4 pp vs 5y</em>
          </div>
        ))}
      </div>
      <p className="source">
        NASS haftalık eyalet şeması; diğer ülkeler resmî bölgesel parser
        doğrulamasından sonra açılır.
      </p>
    </article>
  );
}
function Condition() {
  return (
    <article className="card">
      <p className="eyebrow">CROP CONDITION · STATE</p>
      <h2>Good + Excellent and distribution</h2>
      <div className="conditionRows">
        {regs.map((r) => (
          <div key={r[0]}>
            <span>
              <b>{r[0]}</b>
              <small>
                {r[1]} · G+E {r[3]}%
              </small>
            </span>
            <div className="conditionBand">
              <i style={{ width: "4%" }} />
              <i style={{ width: "7%" }} />
              <i style={{ width: `${89 - r[3]}%` }} />
              <i style={{ width: `${r[3] - 15}%` }} />
              <i style={{ width: "15%" }} />
            </div>
            <b className="nationalDot">●</b>
          </div>
        ))}
      </div>
      <div className="conditionLegend">
        <span>Very poor</span>
        <span>Poor</span>
        <span>Fair</span>
        <span>Good</span>
        <span>Excellent</span>
        <b>● Country avg</b>
      </div>
    </article>
  );
}
function Balance() {
  return (
    <article className="card">
      <p className="eyebrow">USDA WASDE · AUGUST 2026</p>
      <h2>U.S. Wheat Season Balance</h2>
      <div className="balanceGrid">
        <b>Metric</b>
        <b>2026/27</b>
        <b>vs prior</b>
        <b>vs 2025/26</b>
        {[
          ["Harvested area", "12,932 kha", "—", "—"],
          ["Yield", "3.22 t/ha", "−0.3%", "−7.4%"],
          ["Production", "41,658 kt", "−0.3%", "−7.4%"],
          ["Exports", "21,092 kt", "+2.4%", "−5.0%"],
          ["Ending stocks", "19,513 kt", "−0.7%", "−2.0%"],
        ].map((x) => (
          <div className="balanceGridRow" key={x[0]}>
            <strong>{x[0]}</strong>
            <span>{x[1]}</span>
            <i>{x[2]}</i>
            <i>{x[3]}</i>
          </div>
        ))}
      </div>
      <p className="source">
        USDA WASDE / FAS PSD. Haftalık ilerleme ile aylık denge revizyonu
        birbirine karıştırılmaz.
      </p>
    </article>
  );
}
