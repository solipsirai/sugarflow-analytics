import type { Metadata } from "next";
import "./globals.css";
import "./extra.css";
import "./news-fix.css";
import "./extra2.css";
import "./extra3.css";
import "./extra4.css";
import "./extra5.css";
import "./extra6.css";
import "./extra7.css";
import "./wheat.css";
import "./corn.css";
export const metadata: Metadata = {
  title: "AgroFlow Market Intelligence",
  description:
    "Şeker ve buğday traderları için futures, hava, fiziksel piyasa ve temel analiz terminali.",
  other: { "codex-preview": "development" },
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="tr">
      <body>{children}</body>
    </html>
  );
}
