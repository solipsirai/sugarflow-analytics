"use client";

import { useEffect, useMemo, useState } from "react";

const wasdeDates = [
  "2026-08-12T16:00:00Z",
  "2026-09-11T16:00:00Z",
  "2026-10-09T16:00:00Z",
  "2026-11-10T17:00:00Z",
  "2026-12-10T17:00:00Z",
].map((x) => new Date(x));

function weekly(day: number, hourUtc: number, now: Date) {
  const next = new Date(now);
  next.setUTCDate(now.getUTCDate() + ((day - now.getUTCDay() + 7) % 7));
  next.setUTCHours(hourUtc, 0, 0, 0);
  if (next <= now) next.setUTCDate(next.getUTCDate() + 7);
  const last = new Date(next);
  last.setUTCDate(last.getUTCDate() - 7);
  return { last, next };
}

function duration(ms: number) {
  const totalHours = Math.max(0, Math.floor(ms / 3_600_000));
  const days = Math.floor(totalHours / 24);
  const hours = totalHours % 24;
  return days ? `${days}g ${hours}s` : `${hours}s`;
}

export function ReportClock({ includeEia = false }: { includeEia?: boolean }) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 60_000);
    return () => clearInterval(id);
  }, []);
  const rows = useMemo(() => {
    const recurring = [
      ["Crop Progress", 1, 20],
      ["Export Inspections", 1, 16],
      ...(includeEia ? [["EIA Ethanol", 3, 14]] : []),
      ["Export Sales", 4, 12],
      ["CFTC COT", 5, 19],
    ] as Array<[string, number, number]>;
    const regular = recurring.map(([name, day, hour]) => ({
      name,
      ...weekly(day, hour, now),
    }));
    const last =
      [...wasdeDates].reverse().find((x) => x <= now) || wasdeDates[0];
    const next = wasdeDates.find((x) => x > now) || wasdeDates.at(-1)!;
    return [...regular, { name: "WASDE", last, next }];
  }, [now, includeEia]);
  return (
    <div className="reportClock">
      <p className="eyebrow">REPORT CLOCK · UTC</p>
      {rows.map((r) => (
        <div className="clockRow" key={r.name}>
          <b>{r.name}</b>
          <span>
            <i>Geçen</i>
            {duration(now.getTime() - r.last.getTime())}
          </span>
          <span>
            <i>Kalan</i>
            {duration(r.next.getTime() - now.getTime())}
          </span>
          <small>
            {r.next.toLocaleDateString("tr-TR", {
              day: "2-digit",
              month: "short",
            })}
          </small>
        </div>
      ))}
      <p className="clockSource">Takvim: USDA · FAS · CFTC · EIA</p>
    </div>
  );
}
