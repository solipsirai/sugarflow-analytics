"use client";
import { useMemo, useState } from "react";
const specs = {
  "Wheat CBOT/KC/MGEX": {
    unit: "¢/bu",
    weight: 60,
    contract: 5000,
    tick: 0.25,
    tickValue: 12.5,
    toMt: 0.367437,
  },
  "Corn CBOT": {
    unit: "¢/bu",
    weight: 56,
    contract: 5000,
    tick: 0.25,
    tickValue: 12.5,
    toMt: 0.393683,
  },
  "Sugar NY #11": {
    unit: "¢/lb",
    weight: 0,
    contract: 112000,
    tick: 0.01,
    tickValue: 11.2,
    toMt: 22.0462,
  },
};
export function CommodityMath() {
  const [product, setProduct] =
      useState<keyof typeof specs>("Wheat CBOT/KC/MGEX"),
    [value, setValue] = useState(600),
    [direction, setDirection] = useState("benchmark"),
    [lots, setLots] = useState(10),
    [entry, setEntry] = useState(600),
    [exit, setExit] = useState(620),
    [side, setSide] = useState("LONG");
  const s = specs[product],
    converted = direction === "benchmark" ? value * s.toMt : value / s.toMt,
    pnl =
      (side === "LONG" ? 1 : -1) *
      (exit - entry) *
      (product === "Sugar NY #11" ? 1120 : 50) *
      lots;
  return (
    <div className="grid two">
      <article className="card">
        <p className="eyebrow">CROSS-COMMODITY UNIT ENGINE</p>
        <h2>Bushel / ¢lb / Metric Ton</h2>
        <div className="form">
          <label>
            Product
            <select
              value={product}
              onChange={(e) => {
                const p = e.target.value as keyof typeof specs;
                setProduct(p);
                setEntry(p === "Sugar NY #11" ? 17 : 600);
                setExit(p === "Sugar NY #11" ? 18 : 620);
              }}
            >
              {Object.keys(specs).map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </label>
          <label>
            Direction
            <select
              value={direction}
              onChange={(e) => setDirection(e.target.value)}
            >
              <option value="benchmark">{s.unit} → USD/MT</option>
              <option value="mt">USD/MT → {s.unit}</option>
            </select>
          </label>
          <label>
            Value
            <input
              type="number"
              step=".01"
              value={value}
              onChange={(e) => setValue(+e.target.value)}
            />
          </label>
        </div>
        <div className="result">
          <span>
            {direction === "benchmark" ? "USD/MT" : s.unit}
            <small>factor {s.toMt}</small>
          </span>
          <b>{converted.toFixed(2)}</b>
        </div>
      </article>
      <article className="card">
        <p className="eyebrow">LOT P&L</p>
        <h2>Position Calculator</h2>
        <div className="form">
          <label>
            Side
            <select value={side} onChange={(e) => setSide(e.target.value)}>
              <option>LONG</option>
              <option>SHORT</option>
            </select>
          </label>
          <label>
            Lots
            <input
              type="number"
              value={lots}
              onChange={(e) => setLots(+e.target.value)}
            />
          </label>
          <label>
            Entry ({s.unit})
            <input
              type="number"
              step=".01"
              value={entry}
              onChange={(e) => setEntry(+e.target.value)}
            />
          </label>
          <label>
            Exit ({s.unit})
            <input
              type="number"
              step=".01"
              value={exit}
              onChange={(e) => setExit(+e.target.value)}
            />
          </label>
        </div>
        <div className="result">
          <span>
            P&L<small>before fees/margin</small>
          </span>
          <b className={pnl >= 0 ? "up" : "down"}>
            {pnl >= 0 ? "+" : "−"}${Math.abs(pnl).toLocaleString("en-US")}
          </b>
        </div>
      </article>
      <article className="card wide">
        <p className="eyebrow">CONTRACT CHEAT SHEET</p>
        <h2>Research Desk Conversion Table</h2>
        <div className="mathTable">
          <b>Product</b>
          <b>Weight</b>
          <b>Contract</b>
          <b>Min tick</b>
          <b>Tick value</b>
          <b>USD/MT factor</b>
          {Object.entries(specs).map(([k, x]) => (
            <div className="mathTr" key={k}>
              <strong>{k}</strong>
              <span>{x.weight ? `${x.weight} lb/bu` : "lb basis"}</span>
              <span>
                {x.contract.toLocaleString()} {x.weight ? "bu" : "lb"}
              </span>
              <span>
                {x.tick} {x.unit}
              </span>
              <span>${x.tickValue}</span>
              <span>× {x.toMt}</span>
            </div>
          ))}
        </div>
        <p className="source">
          Wheat P&L: 1¢/bu = $50/lot. Corn: 1¢/bu = $50/lot. NY11: 1.00¢/lb =
          $1,120/lot.
        </p>
      </article>
    </div>
  );
}
