"use client";
import { useEffect, useMemo, useState } from "react";
import { CommodityMath } from "./commodity-math";
import { BalanceChart } from "./balance-chart";
import { ReportClock } from "./report-clock";
import { WheatOfficialMonitor } from "./wheat-official-monitor";

type Contract = {
  symbol: string;
  name: string;
  family: string;
  month: string;
  unit: string;
  status: string;
  rollWindow: string;
  lastTrade: string;
  price: number | null;
  change: number | null;
  volume: number | null;
  asOf: string | null;
  source: string;
};
type Day = {
  date: string;
  max: number;
  min: number;
  rain: number;
  prob: number;
  et0: number;
};
type WheatData = {
  generatedAt: string;
  contracts: Contract[];
  weather: Array<{
    id: string;
    name: string;
    region: string;
    crop: string;
    stage: string;
    days: Day[];
  }>;
  cot: Array<{
    label: string;
    date: string;
    long: number;
    short: number;
    spread: number;
    producerLong: number;
    producerShort: number;
    openInterest: number;
  }>;
  news: Array<{
    title: string;
    url: string;
    domain: string;
    date: string;
    category: string;
    source?: string;
  }>;
};
const views = [
  "Wheat Overview",
  "Futures & Spreads",
  "Weather & Crop",
  "Crop Calendar",
  "S&D & Reports",
  "Official Crop Monitor",
  "CFTC Positioning",
  "Exports & Basis",
  "Wheat News",
  "Research Calendar",
  "Contract Guide",
  "Commodity Math",
  "Sources",
];
const icons = [
  "⌁",
  "⇅",
  "☂",
  "◷",
  "▦",
  "◎",
  "◉",
  "⇄",
  "✦",
  "◷",
  "◎",
  "◎",
  "☷",
];
const fmt = (n: number | null, d = 2) =>
  n == null ? "—" : n.toLocaleString("en-US", { maximumFractionDigits: d });
function Tag({
  children,
  live = false,
}: {
  children: React.ReactNode;
  live?: boolean;
}) {
  return (
    <span className={live ? "wtag live" : "wtag"}>
      {live ? "● " : "◷ "}
      {children}
    </span>
  );
}

export function WheatDesk({
  onCommodity,
}: {
  onCommodity: (x: "Sugar" | "Wheat" | "Corn") => void;
}) {
  const [data, setData] = useState<WheatData | null>(null),
    [view, setView] = useState(views[0]),
    [weatherFilter, setWeatherFilter] = useState("All"),
    [newsFilter, setNewsFilter] = useState("All");
  useEffect(() => {
    const load = () =>
      fetch("/api/wheat")
        .then((r) => r.json())
        .then(setData)
        .catch(() =>
          setData({
            generatedAt: new Date().toISOString(),
            contracts: [],
            weather: [],
            cot: [],
            news: [],
          }),
        );
    load();
    const id = setInterval(load, 15 * 60 * 1000);
    return () => clearInterval(id);
  }, []);
  const go = (v: string) => {
    setView(v);
    scrollTo({ top: 0, behavior: "smooth" });
  };
  const front = (family: string) =>
    data?.contracts.find((x) => x.family === family && x.month === "Front");
  return (
    <main className="wheatDesk">
      <header className="topbar">
        <button className="brand" onClick={() => go("Wheat Overview")}>
          <span>W</span>
          <div>
            <b>AGROFLOW</b>
            <small>WHEAT INTELLIGENCE</small>
          </div>
        </button>
        <div className="commoditySwitch">
          <button onClick={() => onCommodity("Sugar")}>Sugar</button>
          <button className="active">Wheat</button>
          <button onClick={() => onCommodity("Corn")}>Corn</button>
        </div>
        <div className="status">
          {data ? "● WHEAT FEEDS BAĞLI" : "◌ BAĞLANIYOR"}
          <i>
            {data &&
              new Date(data.generatedAt).toLocaleTimeString("tr-TR", {
                hour: "2-digit",
                minute: "2-digit",
              })}
          </i>
        </div>
      </header>
      <section className="ticker wheatTicker">
        {[
          ["CBOT SRW", front("SRW")],
          ["KC HRW", front("HRW")],
          ["MGEX HRS", front("HRS")],
          ["MATIF", front("MATIF")],
        ].map(([label, q]: any) => (
          <button key={label} onClick={() => go("Futures & Spreads")}>
            <span>{label} FRONT</span>
            <b>
              {fmt(q?.price)} <em>{q?.unit || "—"}</em>
            </b>
            <Tag>{q?.price != null ? "GECİKMELİ" : "VERİ YOK"}</Tag>
          </button>
        ))}
        <button onClick={() => go("CFTC Positioning")}>
          <span>CFTC SRW NET</span>
          <b>
            {data?.cot[0] ? fmt(data.cot[0].long - data.cot[0].short, 0) : "—"}
          </b>
          <Tag live={!!data?.cot[0]}>HAFTALIK</Tag>
        </button>
      </section>
      <div className="shell">
        <aside>
          <p className="eyebrow">WHEAT DESK</p>
          {views.map((v, i) => (
            <button
              key={v}
              className={view === v ? "selected" : ""}
              onClick={() => go(v)}
            >
              <i>{icons[i]}</i>
              {v}
            </button>
          ))}
          <ReportClock />
        </aside>
        <section className="content">
          <div className="title">
            <div>
              <p className="eyebrow">
                GLOBAL WHEAT DESK / {view.toUpperCase()}
              </p>
              <h1>{view}</h1>
              <p>
                Stage-based weather · benchmark-specific futures · source
                lineage
              </p>
            </div>
            <Tag live={!!data}>15 DK CACHE</Tag>
          </div>
          {view === "Wheat Overview" && <Overview data={data} go={go} />}{" "}
          {view === "Futures & Spreads" && <Futures data={data} />}{" "}
          {view === "Weather & Crop" && (
            <Weather
              data={data}
              filter={weatherFilter}
              setFilter={setWeatherFilter}
            />
          )}{" "}
          {view === "Crop Calendar" && <CropCalendar />}{" "}
          {view === "S&D & Reports" && <Balances />}{" "}
          {view === "Official Crop Monitor" && <WheatOfficialMonitor />}{" "}
          {view === "CFTC Positioning" && <COT data={data} />}{" "}
          {view === "Exports & Basis" && <Exports />}{" "}
          {view === "Wheat News" && (
            <News data={data} filter={newsFilter} setFilter={setNewsFilter} />
          )}{" "}
          {view === "Research Calendar" && <Calendar />}{" "}
          {view === "Contract Guide" && <Guide />}{" "}
          {view === "Commodity Math" && <CommodityMath />}{" "}
          {view === "Sources" && <Sources />}
          <footer>
            <span>
              Wheat data is separated by benchmark, crop class, crop year and
              timestamp.
            </span>
            <b>AGROFLOW · WHEAT v1</b>
          </footer>
        </section>
      </div>
    </main>
  );
}

function wheatSignal(data: WheatData | null) {
  if (!data?.weather.length)
    return { label: "Neutral", score: 0, why: "Weather feed loading" };
  let score = 0,
    dry = 0,
    heat = 0;
  for (const p of data.weather.filter((x) => !x.crop.includes("Corn"))) {
    const rain = p.days.reduce((s, d) => s + d.rain, 0),
      et0 = p.days.reduce((s, d) => s + d.et0, 0),
      mx = Math.max(...p.days.map((d) => d.max));
    if (rain - et0 < -15) {
      score++;
      dry++;
    }
    if (mx > 34) {
      score++;
      heat++;
    }
    if (rain - et0 > 10) score--;
  }
  const change = data.contracts.find(
    (x) => x.family === "SRW" && x.month === "Front",
  )?.change;
  if (change != null) score += change > 0 ? 1 : change < 0 ? -1 : 0;
  return {
    label: score >= 2 ? "Bullish" : score <= -2 ? "Bearish" : "Neutral",
    score,
    why: `${dry} dry-balance regions · ${heat} heat-watch regions · SRW ${change == null ? "unavailable" : change > 0 ? "up" : change < 0 ? "down" : "flat"}`,
  };
}

function Overview({
  data,
  go,
}: {
  data: WheatData | null;
  go: (x: string) => void;
}) {
  const auto = wheatSignal(data),
    hrw = data?.weather.find((x) => x.id === "kansas"),
    rain = hrw?.days.reduce((s, d) => s + d.rain, 0) || 0,
    srw = data?.contracts.find(
      (x) => x.family === "SRW" && x.month === "Front",
    ),
    hrwq = data?.contracts.find(
      (x) => x.family === "HRW" && x.month === "Front",
    ),
    spread =
      srw?.price != null && hrwq?.price != null ? hrwq.price - srw.price : null;
  return (
    <>
      <div className={`signal wheatSignal ${auto.label.toLowerCase()}`}>
        <span>AUTOMATIC WHEAT DESK READ</span>
        <b>
          {auto.label} · Score {auto.score > 0 ? "+" : ""}
          {auto.score}
        </b>
        <p>
          {auto.why} · 7d Kansas rain: {rain.toFixed(1)} mm · HRW–SRW:{" "}
          {spread == null ? "feed unavailable" : `${spread.toFixed(1)} ¢/bu`}.
        </p>
        <strong>{auto.label.toUpperCase()}</strong>
      </div>
      <div className="grid overview">
        <button className="card action" onClick={() => go("Weather & Crop")}>
          <Tag live={!!data?.weather.length}>WEATHER</Tag>
          <p className="eyebrow">US CROP BELTS</p>
          <h2>{data?.weather.length || 0} regions</h2>
          <span>Stage-based risk monitor →</span>
        </button>
        <button className="card action" onClick={() => go("CFTC Positioning")}>
          <Tag live={!!data?.cot.length}>CFTC</Tag>
          <p className="eyebrow">SRW MANAGED MONEY</p>
          <h2>
            {data?.cot[0] ? fmt(data.cot[0].long - data.cot[0].short, 0) : "—"}
          </h2>
          <span>SRW / HRW / HRS breakdown →</span>
        </button>
        <button className="card action" onClick={() => go("S&D & Reports")}>
          <Tag>USDA</Tag>
          <p className="eyebrow">REPORT STACK</p>
          <h2>WASDE + NASS</h2>
          <span>S&D and release calendar →</span>
        </button>
      </div>
      <div className="grid two">
        <article className="card">
          <p className="eyebrow">BENCHMARK MAP</p>
          <h2>Which Wheat Trades Where?</h2>
          {[
            [
              "CBOT SRW",
              "Soft Red Winter",
              "Chicago · global feed/low-protein reference",
            ],
            ["KC HRW", "Hard Red Winter", "Kansas City · US bread wheat"],
            [
              "MGEX HRS",
              "Hard Red Spring",
              "Minneapolis · high-protein premium",
            ],
            [
              "Euronext MATIF",
              "Milling Wheat",
              "Paris · EU/Black Sea-linked benchmark",
            ],
          ].map((x) => (
            <div className="wheatClass" key={x[0]}>
              <b>{x[0]}</b>
              <span>{x[1]}</span>
              <small>{x[2]}</small>
            </div>
          ))}
        </article>
        <article className="card">
          <p className="eyebrow">KEY DRIVERS</p>
          <h2>Daily Wheat Checklist</h2>
          {[
            "Black Sea exports & war/logistics",
            "Russia/Ukraine/EU crop estimates",
            "US HRW/SRW/HRS crop conditions",
            "China/Egypt/Algeria/Türkiye tenders",
            "USD, freight and importer currencies",
            "Protein spreads, basis and HRW–SRW",
          ].map((x, i) => (
            <div className="health" key={x}>
              <span>{x}</span>
              <b>{String(i + 1).padStart(2, "0")}</b>
            </div>
          ))}
        </article>
      </div>
    </>
  );
}

function Futures({ data }: { data: WheatData | null }) {
  const rows = data?.contracts || [],
    srw = rows.find((x) => x.family === "SRW" && x.month === "Front"),
    hrw = rows.find((x) => x.family === "HRW" && x.month === "Front");
  return (
    <>
      <article className="card">
        <div className="cardhead">
          <div>
            <p className="eyebrow">FUTURES BOARD · SOURCE/TIME ON EVERY ROW</p>
            <h2>All Wheat Benchmarks & Active Months</h2>
          </div>
          <Tag>EXCHANGE-DELAYED</Tag>
        </div>
        <div className="wheatContractTable">
          <b>Benchmark / contract</b>
          <b>Price</b>
          <b>Δ</b>
          <b>Volume</b>
          <b>Status / roll</b>
          <b>Source / time</b>
          {rows.map((q) => (
            <div className="wheatContractTr" key={q.symbol}>
              <strong>
                {q.name}
                <small>
                  {q.symbol} · {q.family}
                </small>
              </strong>
              <b>
                {fmt(q.price)} {q.unit}
              </b>
              <i className={(q.change || 0) >= 0 ? "up" : "down"}>
                {q.change == null
                  ? "—"
                  : `${q.change >= 0 ? "+" : ""}${q.change.toFixed(2)}`}
              </i>
              <span>{fmt(q.volume, 0)}</span>
              <em>
                {q.status}
                <small>
                  {q.rollWindow} · LTD {q.lastTrade}
                </small>
              </em>
              <small>
                {q.source}
                <br />
                {q.asOf
                  ? new Date(q.asOf).toLocaleString("tr-TR")
                  : "timestamp yok"}
              </small>
            </div>
          ))}
        </div>
        <p className="source">
          Operational roll alert uses volume/open-interest crossover plus the
          desk window; always verify the official CME/MGEX/Euronext calendar
          before delivery month.
        </p>
      </article>
      <div className="grid two">
        <article className="card">
          <p className="eyebrow">INTER-MARKET SPREAD</p>
          <h2>HRW − SRW Protein Premium</h2>
          <div className="heroMetric">
            <span>Front spread</span>
            <b>
              {srw?.price != null && hrw?.price != null
                ? `${(hrw.price - srw.price).toFixed(2)} ¢/bu`
                : "Feed unavailable"}
            </b>
          </div>
          <p className="source">
            Positive spread = bread/high-protein HRW premium over softer SRW.
            Compare matched months before interpreting.
          </p>
        </article>
        <BushelConverter />
      </div>
    </>
  );
}
function BushelConverter() {
  const [v, setV] = useState(600),
    [mode, setMode] = useState("cents");
  const usdmt = mode === "cents" ? v * 0.367437 : v / 0.367437;
  return (
    <article className="card">
      <p className="eyebrow">UNIT ENGINE</p>
      <h2>¢/bu ↔ USD/MT</h2>
      <div className="form">
        <label>
          Direction
          <select value={mode} onChange={(e) => setMode(e.target.value)}>
            <option value="cents">¢/bu → USD/MT</option>
            <option value="mt">USD/MT → ¢/bu</option>
          </select>
        </label>
        <label>
          Value
          <input
            type="number"
            value={v}
            onChange={(e) => setV(+e.target.value)}
          />
        </label>
      </div>
      <div className="result">
        <span>
          {mode === "cents" ? "USD/MT" : "US¢/bu"}
          <small>Wheat: 60 lb/bu</small>
        </span>
        <b>{usdmt.toFixed(2)}</b>
      </div>
      <p className="source">
        1 wheat bushel = 60 lb = 27.2155 kg. 1 ¢/bu = about $0.36744/MT.
      </p>
    </article>
  );
}

function Weather({
  data,
  filter,
  setFilter,
}: {
  data: WheatData | null;
  filter: string;
  setFilter: (x: string) => void;
}) {
  const filters = ["All", "HRW", "SRW", "HRS", "Corn", "White wheat"],
    shown = (data?.weather || []).filter(
      (x) =>
        filter === "All" || x.crop.toLowerCase().includes(filter.toLowerCase()),
    );
  return (
    <>
      <div className="weatherTabs wheatFilters">
        {filters.map((f) => (
          <button
            key={f}
            className={filter === f ? "active" : ""}
            onClick={() => setFilter(f)}
          >
            {f}{" "}
            <small>
              {f === "All"
                ? data?.weather.length || 0
                : (data?.weather || []).filter((x) =>
                    x.crop.toLowerCase().includes(f.toLowerCase()),
                  ).length}
            </small>
          </button>
        ))}
      </div>
      <div className="grid chartGrid">
        {shown.map((p) => {
          const rain = p.days.reduce((s, d) => s + d.rain, 0),
            et0 = p.days.reduce((s, d) => s + d.et0, 0),
            max = Math.max(...p.days.map((d) => d.max)),
            risk =
              rain < 10 && et0 > 25
                ? "DRY WATCH"
                : max > 35
                  ? "HEAT WATCH"
                  : "NORMAL";
          return (
            <article className="card crop" key={p.id}>
              <p className="eyebrow">OPEN-METEO · {p.region}</p>
              <h2>{p.name}</h2>
              <div
                className={
                  risk === "NORMAL"
                    ? "conditionScore"
                    : "conditionScore warnBox"
                }
              >
                {risk}
              </div>
              <div className="cropMeta">
                <b>{p.crop}</b>
                <span>{p.stage}</span>
              </div>
              {[
                ["7d rain", `${rain.toFixed(1)} mm`],
                ["7d ET₀", `${et0.toFixed(1)} mm`],
                ["Max temp", `${max.toFixed(1)}°C`],
                ["Water balance proxy", `${(rain - et0).toFixed(1)} mm`],
              ].map((x) => (
                <div className="health" key={x[0]}>
                  <span>{x[0]}</span>
                  <b>{x[1]}</b>
                </div>
              ))}
              <div className="microForecast">
                {p.days.map((d) => (
                  <div key={d.date}>
                    <span>
                      {new Date(d.date).toLocaleDateString("tr-TR", {
                        weekday: "short",
                      })}
                    </span>
                    <b>{d.max.toFixed(0)}°</b>
                    <i>{d.rain.toFixed(1)}mm</i>
                  </div>
                ))}
              </div>
            </article>
          );
        })}
      </div>
      <article className="card">
        <p className="eyebrow">HOW TO READ</p>
        <h2>Weather Impact by Stage</h2>
        <div className="stageGrid">
          {[
            [
              "HRW planting/emergence",
              "Topsoil moisture; rain helps establishment, excessive rain delays planting.",
            ],
            [
              "Winter dormancy",
              "Snow cover protects against winterkill; bare fields amplify cold risk.",
            ],
            [
              "Jointing/heading",
              "Heat and drought reduce tillers and yield potential.",
            ],
            [
              "Flowering/grain fill",
              "Heat/frost are highest-impact; quality and test weight at risk.",
            ],
            [
              "Harvest",
              "Dry weather accelerates harvest; rain raises sprouting/quality risk.",
            ],
            [
              "Corn silking/fill",
              "Heat + moisture deficit is critical; included now for the coming Corn Desk.",
            ],
          ].map((x) => (
            <div key={x[0]}>
              <b>{x[0]}</b>
              <p>{x[1]}</p>
            </div>
          ))}
        </div>
      </article>
    </>
  );
}

function CropCalendar() {
  const now = new Date();
  const todayLeft = `calc(180px + (100% - 180px) * ${(now.getMonth() + (now.getDate() - 1) / new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate()) / 12})`;
  const months = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];
  const rows = [
    {
      crop: "US HRW",
      region: "KS · OK · TX",
      plant: [9, 10, 11],
      grow: [1, 2, 3, 4, 5],
      harvest: [5, 6, 7],
      note: "Winter wheat · bread wheat",
    },
    {
      crop: "US SRW",
      region: "OH · IN · IL · MO",
      plant: [9, 10, 11],
      grow: [1, 2, 3, 4, 5],
      harvest: [6, 7],
      note: "Winter wheat · soft wheat",
    },
    {
      crop: "US HRS",
      region: "ND · MN · MT",
      plant: [4, 5],
      grow: [5, 6, 7, 8],
      harvest: [8, 9],
      note: "Spring wheat · high protein",
    },
    {
      crop: "US White Wheat",
      region: "WA · OR · ID",
      plant: [9, 10, 11, 3, 4],
      grow: [1, 2, 3, 4, 5, 6],
      harvest: [7, 8, 9],
      note: "Winter + spring types",
    },
    {
      crop: "EU Milling",
      region: "France · Germany · Romania",
      plant: [9, 10, 11],
      grow: [1, 2, 3, 4, 5, 6],
      harvest: [7, 8],
      note: "MATIF-linked crop",
    },
    {
      crop: "Russia Wheat",
      region: "South · Volga · Central",
      plant: [8, 9, 10],
      grow: [1, 2, 3, 4, 5, 6],
      harvest: [7, 8, 9],
      note: "Winter crop dominates exports",
    },
    {
      crop: "Ukraine Wheat",
      region: "South · East · Central",
      plant: [9, 10],
      grow: [1, 2, 3, 4, 5, 6],
      harvest: [7, 8],
      note: "Black Sea flow",
    },
    {
      crop: "Canada HRS",
      region: "SK · AB · MB",
      plant: [4, 5],
      grow: [5, 6, 7, 8],
      harvest: [8, 9, 10],
      note: "Spring/high-protein wheat",
    },
    {
      crop: "Australia Wheat",
      region: "WA · NSW · VIC",
      plant: [4, 5, 6],
      grow: [6, 7, 8, 9, 10],
      harvest: [10, 11, 12],
      note: "Southern Hemisphere",
    },
    {
      crop: "Argentina Wheat",
      region: "Buenos Aires · Córdoba",
      plant: [5, 6, 7],
      grow: [7, 8, 9, 10, 11],
      harvest: [11, 12, 1],
      note: "Southern Hemisphere",
    },
    {
      crop: "US Corn",
      region: "IA · IL · NE · MN · IN",
      plant: [4, 5, 6],
      grow: [6, 7, 8, 9],
      harvest: [9, 10, 11],
      note: "Corn Desk infrastructure",
    },
  ];
  return (
    <article className="card">
      <div className="cardhead">
        <div>
          <p className="eyebrow">GLOBAL CROP CALENDAR · DESK WINDOWS</p>
          <h2>Wheat Classes + US Corn</h2>
        </div>
        <Tag>STAGE MAP</Tag>
      </div>
      <div className="calendarScroll">
        <div className="calendarPosition">
          <div className="todayLine" style={{ left: todayLeft }}>
            <b>
              {now.toLocaleDateString("tr-TR", {
                day: "2-digit",
                month: "short",
              })}
            </b>
          </div>
          <div className="wheatCalendar">
            <b>Crop / region</b>
            {months.map((m) => (
              <b key={m}>{m}</b>
            ))}
            {rows.map((r) => (
              <div className="wheatCalRow" key={r.crop}>
                <strong>
                  {r.crop}
                  <small>
                    {r.region}
                    <br />
                    {r.note}
                  </small>
                </strong>
                {months.map((_, i) => {
                  const m = i + 1,
                    cls = r.harvest.includes(m)
                      ? "harvest"
                      : r.plant.includes(m)
                        ? "plant"
                        : r.grow.includes(m)
                          ? "grow"
                          : "";
                  return (
                    <span className={cls} key={m}>
                      {cls === "harvest"
                        ? "H"
                        : cls === "plant"
                          ? "P"
                          : cls === "grow"
                            ? "G"
                            : ""}
                    </span>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="calendarLegend">
        <span>
          <i className="plant" />
          Planting
        </span>
        <span>
          <i className="grow" />
          Growing / development
        </span>
        <span>
          <i className="harvest" />
          Harvest
        </span>
      </div>
      <p className="source">
        Operational monitoring windows; exact dates vary by state and crop year.
        Interpret weather with the current crop stage and official regional
        calendars.
      </p>
    </article>
  );
}

function Balances() {
  const rows = [
    [
      ["US Wheat S&D", "WASDE", "Monthly"],
      ["World Wheat S&D", "WASDE/PSD", "Monthly"],
      ["Winter Wheat Production", "NASS Crop Production", "Monthly/in-season"],
      ["Crop Condition & Progress", "NASS Crop Progress", "Monday"],
      ["Acreage / Stocks", "NASS Acreage & Grain Stocks", "Quarterly/annual"],
      ["Export Sales", "FAS ESR", "Thursday"],
      ["Export Inspections", "FAS", "Monday"],
    ],
    [
      ["Production", "By class + total; current vs prior estimate"],
      ["Feed & residual", "Price-sensitive domestic use"],
      ["Exports", "Competitiveness and pace vs USDA target"],
      ["Ending stocks", "Absolute buffer"],
      ["Stocks/use", "Tightness normalized by demand"],
      ["Yield / harvested area", "Separate area shock from agronomic shock"],
    ],
  ];
  return (
    <div className="grid two">
      <BalanceChart
        title="U.S. Wheat 2026/27"
        unit="Million bushels"
        values={[
          ["Production", 1531],
          ["Domestic use", 1099],
          ["Exports", 775, "export"],
          ["Ending stocks", 717, "stock"],
        ]}
      />
      <BalanceChart
        title="World Wheat 2026/27"
        unit="Million tonnes"
        values={[
          ["Production", 819.3],
          ["Consumption", 826.27],
          ["Ending stocks", 273.25, "stock"],
        ]}
      />
      <article className="card wide revisionCard">
        <p className="eyebrow">JULY → AUGUST REVISION</p>
        <h2>What changed?</h2>
        <div className="revisionGrid">
          <span>
            U.S. production <b>1,536 → 1,531</b>
            <i>−5 M bu</i>
          </span>
          <span>
            U.S. ending stocks <b>722 → 717</b>
            <i>−5 M bu</i>
          </span>
          <span>
            World production <b>819.97 → 819.30</b>
            <i>−0.67 MMT</i>
          </span>
          <span>
            World stocks <b>272.84 → 273.25</b>
            <i>+0.41 MMT</i>
          </span>
        </div>
      </article>
      <article className="card">
        <p className="eyebrow">OFFICIAL REPORT STACK</p>
        <h2>USDA Wheat Reports</h2>
        {rows[0].map((x) => (
          <div className="reportRow" key={x[0]}>
            <b>{x[0]}</b>
            <span>{x[1]}</span>
            <i>{x[2]}</i>
          </div>
        ))}
      </article>
      <article className="card">
        <p className="eyebrow">WASDE READING ORDER</p>
        <h2>What Changes the Price?</h2>
        {rows[1].map((x, i) => (
          <div className="reportRow" key={x[0]}>
            <b>
              {String(i + 1).padStart(2, "0")} · {x[0]}
            </b>
            <span>{x[1]}</span>
          </div>
        ))}
      </article>
      <article className="card wide">
        <p className="eyebrow">GLOBAL ORIGINS</p>
        <h2>Minimum Global Balance Watch</h2>
        <div className="originMatrix">
          <b>Origin</b>
          <b>Why it matters</b>
          <b>Key data</b>
          {[
            [
              "Russia",
              "Largest/major low-cost exporter",
              "Crop, export tax, Black Sea FOB, ports",
            ],
            [
              "EU",
              "Milling wheat exporter and MATIF anchor",
              "France/Germany/Romania crop, quality",
            ],
            [
              "Ukraine",
              "Black Sea flow and logistics risk",
              "Ports, corridor, crop, freight",
            ],
            [
              "US",
              "Residual supplier + benchmark complex",
              "Classes, exports, basis, USD",
            ],
            [
              "Canada",
              "High-protein spring wheat",
              "Production, protein, stocks",
            ],
            [
              "Australia",
              "Asian supply and seasonal hedge",
              "Rainfall, harvest, APW prices",
            ],
            [
              "Argentina",
              "Southern Hemisphere swing supplier",
              "Crop, export policy, peso",
            ],
            [
              "China/India",
              "Large balances; policy can reshape trade",
              "Stocks, auctions, imports/exports",
            ],
          ].map((x) => (
            <div className="originMatrixRow" key={x[0]}>
              <strong>{x[0]}</strong>
              <span>{x[1]}</span>
              <span>{x[2]}</span>
            </div>
          ))}
        </div>
      </article>
    </div>
  );
}

function COT({ data }: { data: WheatData | null }) {
  return (
    <div className="grid chartGrid">
      {(data?.cot || []).map((c) => {
        const net = c.long - c.short,
          share = c.openInterest ? (net / c.openInterest) * 100 : 0;
        return (
          <article className="card" key={c.label}>
            <p className="eyebrow">CFTC PRE · {c.date}</p>
            <h2>{c.label}</h2>
            <div className="heroMetric">
              <span>Managed Money net</span>
              <b className={net >= 0 ? "up" : "down"}>{fmt(net, 0)}</b>
            </div>
            {[
              ["Long", c.long],
              ["Short", c.short],
              ["Spreading", c.spread],
              ["Open interest", c.openInterest],
              ["Net / OI", `${share.toFixed(1)}%`],
            ].map((x) => (
              <div className="health" key={x[0]}>
                <span>{x[0]}</span>
                <b>{typeof x[1] === "number" ? fmt(x[1], 0) : x[1]}</b>
              </div>
            ))}
            <p className="source">
              {net < 0
                ? "Net short: short-covering fuel exists, but trend remains bearish until flows change."
                : "Net long: liquidation risk rises if fundamentals disappoint."}
            </p>
          </article>
        );
      })}
    </div>
  );
}
function Exports() {
  return (
    <div className="grid two">
      <article className="card">
        <p className="eyebrow">US EXPORT DASHBOARD</p>
        <h2>Weekly Pace Checklist</h2>
        {[
          ["Export Sales", "Net sales, cancellations, next MY sales"],
          ["Shipments", "Weekly + cumulative vs USDA annual target"],
          ["Inspections", "Destination, port range, class clues"],
          ["Outstanding sales", "Unshipped commitment and execution risk"],
          ["Basis", "Gulf / PNW / interior cash signal"],
          ["Freight", "US Gulf vs Black Sea landed competitiveness"],
        ].map((x) => (
          <div className="explain" key={x[0]}>
            <b>{x[0]}</b>
            <p>{x[1]}</p>
          </div>
        ))}
      </article>
      <article className="card">
        <p className="eyebrow">TENDER / DESTINATION WATCH</p>
        <h2>Demand Signals</h2>
        {[
          [
            "Egypt / Mostakbal Misr",
            "Large tenders; Black Sea competitiveness",
          ],
          ["Algeria / OAIC", "Milling quality and EU/Black Sea flows"],
          ["Saudi Arabia / GFSA", "Hard wheat demand"],
          ["Türkiye / TMO", "Policy-sensitive importer/exporter"],
          ["Iraq", "US/Australia/Black Sea competition"],
          ["China", "Large, episodic state-linked purchases"],
          ["Japan / MAFF", "Regular high-quality tenders; class-specific"],
        ].map((x) => (
          <div className="origin" key={x[0]}>
            <b>{x[0]}</b>
            <span>{x[1]}</span>
          </div>
        ))}
      </article>
      <article className="card wide">
        <p className="eyebrow">BASIS INPUT BOARD</p>
        <h2>Physical Wheat Fields to Upload</h2>
        <div className="physicalTable">
          <b>Market</b>
          <b>Class</b>
          <b>Quote</b>
          <b>Incoterm</b>
          <b>Source</b>
          {[
            [
              "US Gulf",
              "SRW/HRW",
              "¢/bu over futures",
              "FOB",
              "Broker/USDA AMS",
            ],
            [
              "PNW",
              "HRS/HRW/White",
              "$/MT or ¢/bu",
              "FOB",
              "USDA AMS/exporter",
            ],
            [
              "Black Sea",
              "12.5% wheat",
              "$/MT",
              "FOB",
              "Fastmarkets/Platts/Argus",
            ],
            ["Rouen", "Milling wheat", "€/MT", "FOB", "Euronext/FranceAgriMer"],
            [
              "Argentina",
              "12% wheat",
              "$/MT",
              "FOB Up River",
              "Broker/provider",
            ],
          ].map((x) => (
            <div className="physicalTr" key={x[0]}>
              {x.map((v) => (
                <span key={v}>{v}</span>
              ))}
            </div>
          ))}
        </div>
      </article>
    </div>
  );
}

function News({
  data,
  filter,
  setFilter,
}: {
  data: WheatData | null;
  filter: string;
  setFilter: (x: string) => void;
}) {
  const filters = ["All", "Wheat", "Weather", "Trade"],
    shown = (data?.news || []).filter(
      (n) => filter === "All" || n.category === filter,
    );
  return (
    <>
      <div className="newsHero">
        <div>
          <p className="eyebrow">WHEAT + GRAINS INTELLIGENCE</p>
          <h2>{shown.length} stories</h2>
          <p>GDELT discovery feed; every item opens the original publisher.</p>
        </div>
      </div>
      <div className="newsFilters">
        {filters.map((f) => (
          <button
            key={f}
            className={filter === f ? "active" : ""}
            onClick={() => setFilter(f)}
          >
            {filter === f ? "● " : ""}
            {f}
          </button>
        ))}
      </div>
      <div className="newsList">
        {shown.map((n, i) => (
          <a
            href={n.url}
            target="_blank"
            rel="noopener noreferrer"
            className="newsItem"
            key={n.url}
          >
            <div className="newsIndex">{String(i + 1).padStart(2, "0")}</div>
            <div>
              <p className="eyebrow">
                {n.domain} · {n.source || "GDELT discovery"} ·{" "}
                {n.date?.slice(0, 8)}
              </p>
              <h3>{n.title}</h3>
              <span>{n.category.toUpperCase()}</span>
            </div>
            <b>↗</b>
          </a>
        ))}
      </div>
    </>
  );
}
function Calendar() {
  const rows = [
    [
      "Every morning",
      "CBOT/KC/MGEX/MATIF, spreads, USD, freight",
      "Price direction + relative value",
    ],
    [
      "Every morning",
      "Kansas/TX-OK/Dakotas/Ohio Valley/Corn Belt weather by stage",
      "Yield, planting or harvest risk",
    ],
    [
      "Monday",
      "NASS Crop Progress + Export Inspections",
      "Condition/progress and shipment pace",
    ],
    [
      "Thursday",
      "USDA Export Sales",
      "New demand, cancellations, destinations",
    ],
    ["Friday", "CFTC positioning", "Crowding, liquidation, short-covering"],
    ["Monthly", "WASDE + Crop Production", "Production/use/stocks revisions"],
    ["Quarterly", "Grain Stocks + Acreage", "Residual use and area reset"],
    [
      "Event-driven",
      "Black Sea policy/war, tenders, export taxes",
      "Physical flow shock",
    ],
  ];
  return (
    <article className="card">
      <p className="eyebrow">DESK OPERATING RHYTHM</p>
      <h2>What to Track, When and Why</h2>
      <div className="researchTable wheatResearch">
        <b>Frequency</b>
        <b>Check</b>
        <b>Trader purpose</b>
        {rows.map((r) => (
          <div className="researchTr" key={r[0] + r[1]}>
            <strong>{r[0]}</strong>
            <span>{r[1]}</span>
            <span>{r[2]}</span>
          </div>
        ))}
      </div>
    </article>
  );
}
function Guide() {
  const rows = [
    [
      "CBOT SRW",
      "ZW",
      "5,000 bu",
      "60 lb/bu",
      "Mar May Jul Sep Dec",
      "Soft wheat / global reference",
    ],
    [
      "KC HRW",
      "KE",
      "5,000 bu",
      "60 lb/bu",
      "Mar May Jul Sep Dec",
      "Bread wheat / Plains",
    ],
    [
      "MGEX HRS",
      "MWE/MW",
      "5,000 bu",
      "60 lb/bu",
      "Mar May Jul Sep Dec",
      "High-protein spring wheat",
    ],
    [
      "Euronext Milling Wheat",
      "EBM",
      "50 MT",
      "EUR/MT",
      "Mar May Sep Dec",
      "EU milling benchmark",
    ],
  ];
  return (
    <div className="grid two">
      <article className="card wide">
        <p className="eyebrow">CONTRACT SPECIFICATIONS</p>
        <h2>Wheat Derivatives Map</h2>
        <div className="guideTable">
          <b>Contract</b>
          <b>Code</b>
          <b>Size</b>
          <b>Weight</b>
          <b>Months</b>
          <b>Use</b>
          {rows.map((r) => (
            <div className="guideTr" key={r[0]}>
              {r.map((x) => (
                <span key={x}>{x}</span>
              ))}
            </div>
          ))}
        </div>
        <p className="source">
          Final delivery rules, limits and dates must be verified with the
          exchange rulebook. Mini/micro availability and liquidity vary by
          venue.
        </p>
      </article>
      <article className="card">
        <p className="eyebrow">RELATIVE VALUE</p>
        <h2>Core Spreads</h2>
        {[
          "Calendar: Dec–Mar, Mar–May, May–Jul",
          "HRW–SRW protein/quality spread",
          "HRS–HRW high-protein spread",
          "MATIF–CBOT after FX and freight",
          "Cash basis = cash price − futures",
          "Black Sea FOB vs landed destination",
        ].map((x) => (
          <div className="health" key={x}>
            <span>{x}</span>
            <b>→</b>
          </div>
        ))}
      </article>
      <article className="card">
        <p className="eyebrow">RISK</p>
        <h2>Before You Trade</h2>
        {[
          "Active crop year?",
          "Front month or most-liquid month?",
          "Volume/OI moved to next month?",
          "Matched months in spread?",
          "Basis and quality comparable?",
          "Delivery/limit-move exposure?",
        ].map((x, i) => (
          <div className="health" key={x}>
            <span>{x}</span>
            <b>{i + 1}</b>
          </div>
        ))}
      </article>
    </div>
  );
}
function Sources() {
  const rows = [
    [
      "CME Group",
      "CBOT SRW / KC HRW specs, calendar, settlements",
      "Official exchange",
      "Delayed/public pages; live license",
    ],
    [
      "MGEX",
      "HRS specs and calendar",
      "Official exchange",
      "Public specs; market data terms",
    ],
    [
      "Euronext",
      "Milling Wheat specs/calendar",
      "Official exchange",
      "Public specs; live license",
    ],
    ["USDA WASDE/PSD", "US + world S&D", "Official", "Free"],
    [
      "USDA NASS",
      "Crop progress, acreage, stocks, production",
      "Official",
      "Free / API key for automation",
    ],
    ["USDA FAS", "Export sales, inspections, PSD", "Official", "Free"],
    ["CFTC PRE", "Managed Money / producer / OI", "Official API", "Free"],
    ["Open-Meteo", "7d weather + ET₀ proxy", "Open weather API", "Free"],
    ["GDELT", "News discovery and source URLs", "Aggregator", "Free"],
    ["USDA AMS", "Cash grain/basis reports", "Official", "Free"],
    [
      "LSEG/Bloomberg/ICE/CME vendors",
      "Live futures, curves, options, news",
      "Licensed",
      "Enterprise entitlement",
    ],
    [
      "Fastmarkets/Platts/Argus",
      "FOB, basis, Black Sea physical assessments",
      "Price reporting agencies",
      "Subscription",
    ],
  ];
  return (
    <article className="card">
      <p className="eyebrow">DATA LINEAGE</p>
      <h2>Wheat Sources: Field, Quality and License</h2>
      <div className="sourceTable">
        <b>Source</b>
        <b>Data</b>
        <b>Quality</b>
        <b>Access</b>
        {rows.map((r) => (
          <div className="sourceTr" key={r[0]}>
            <strong>{r[0]}</strong>
            <span>{r[1]}</span>
            <span>{r[2]}</span>
            <span>{r[3]}</span>
          </div>
        ))}
      </div>
    </article>
  );
}
