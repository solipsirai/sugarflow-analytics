export const dynamic = "force-dynamic";

type QuoteDef = {
  symbol: string;
  name: string;
  family: string;
  month: string;
  unit: string;
  status: string;
  rollWindow: string;
  lastTrade: string;
};
const quoteDefs: QuoteDef[] = [
  {
    symbol: "ZW=F",
    name: "CBOT SRW Wheat Front",
    family: "SRW",
    month: "Front",
    unit: "US¢/bu",
    status: "FRONT",
    rollWindow: "Volume/OI crossover",
    lastTrade: "CME calendar",
  },
  {
    symbol: "ZWU26.CBT",
    name: "CBOT SRW Sep 2026",
    family: "SRW",
    month: "Sep-26",
    unit: "US¢/bu",
    status: "EXPIRING",
    rollWindow: "07–11 Sep 2026",
    lastTrade: "14 Sep 2026",
  },
  {
    symbol: "ZWZ26.CBT",
    name: "CBOT SRW Dec 2026",
    family: "SRW",
    month: "Dec-26",
    unit: "US¢/bu",
    status: "NEXT / LIQUID",
    rollWindow: "07–11 Dec 2026",
    lastTrade: "14 Dec 2026",
  },
  {
    symbol: "ZWH27.CBT",
    name: "CBOT SRW Mar 2027",
    family: "SRW",
    month: "Mar-27",
    unit: "US¢/bu",
    status: "DEFERRED",
    rollWindow: "08–12 Mar 2027",
    lastTrade: "12 Mar 2027",
  },
  {
    symbol: "KE=F",
    name: "KC HRW Wheat Front",
    family: "HRW",
    month: "Front",
    unit: "US¢/bu",
    status: "FRONT",
    rollWindow: "Volume/OI crossover",
    lastTrade: "CME calendar",
  },
  {
    symbol: "KEU26.CBT",
    name: "KC HRW Sep 2026",
    family: "HRW",
    month: "Sep-26",
    unit: "US¢/bu",
    status: "EXPIRING",
    rollWindow: "07–11 Sep 2026",
    lastTrade: "14 Sep 2026",
  },
  {
    symbol: "KEZ26.CBT",
    name: "KC HRW Dec 2026",
    family: "HRW",
    month: "Dec-26",
    unit: "US¢/bu",
    status: "NEXT / LIQUID",
    rollWindow: "07–11 Dec 2026",
    lastTrade: "14 Dec 2026",
  },
  {
    symbol: "MWE=F",
    name: "MGEX HRS Wheat Front",
    family: "HRS",
    month: "Front",
    unit: "US¢/bu",
    status: "VERIFY FEED",
    rollWindow: "Volume/OI crossover",
    lastTrade: "MGEX calendar",
  },
  {
    symbol: "EBM=F",
    name: "Euronext Milling Wheat Front",
    family: "MATIF",
    month: "Front",
    unit: "EUR/MT",
    status: "VERIFY FEED",
    rollWindow: "Euronext calendar",
    lastTrade: "Euronext calendar",
  },
];

const places = [
  {
    id: "kansas",
    name: "Garden City, Kansas",
    region: "Central/SW Kansas",
    crop: "HRW",
    stage: "Post-harvest / planting prep",
    lat: 37.97,
    lon: -100.87,
  },
  {
    id: "texas",
    name: "Amarillo, Texas",
    region: "TX/OK Panhandle",
    crop: "HRW",
    stage: "Planting moisture watch",
    lat: 35.22,
    lon: -101.83,
  },
  {
    id: "dakota",
    name: "Fargo, North Dakota",
    region: "Northern Plains",
    crop: "HRS + Corn",
    stage: "Spring wheat harvest / corn fill",
    lat: 46.88,
    lon: -96.79,
  },
  {
    id: "ohio",
    name: "Columbus, Ohio",
    region: "Ohio Valley",
    crop: "SRW + Corn",
    stage: "Corn fill / SRW planting prep",
    lat: 39.96,
    lon: -83.0,
  },
  {
    id: "iowa",
    name: "Des Moines, Iowa",
    region: "Central Corn Belt",
    crop: "Corn",
    stage: "Grain fill",
    lat: 41.59,
    lon: -93.62,
  },
  {
    id: "illinois",
    name: "Springfield, Illinois",
    region: "Eastern Corn Belt",
    crop: "Corn + SRW",
    stage: "Grain fill / planting prep",
    lat: 39.8,
    lon: -89.64,
  },
  {
    id: "washington",
    name: "Pullman, Washington",
    region: "Pacific Northwest",
    crop: "White wheat",
    stage: "Harvest",
    lat: 46.73,
    lon: -117.18,
  },
];

async function quote(d: QuoteDef) {
  try {
    const r = await fetch(
      `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(d.symbol)}?interval=1d&range=5d`,
      {
        headers: { "User-Agent": "Mozilla/5.0 AgroFlow/1.0" },
        next: { revalidate: 900 },
      },
    );
    if (!r.ok) throw Error("quote");
    const x = (await r.json())?.chart?.result?.[0],
      m = x?.meta,
      q = x?.indicators?.quote?.[0],
      cl = (q?.close || []).filter(Number.isFinite),
      vol = (q?.volume || []).filter(Number.isFinite),
      price = Number.isFinite(m?.regularMarketPrice)
        ? m.regularMarketPrice
        : cl.at(-1),
      prev = Number.isFinite(m?.chartPreviousClose)
        ? m.chartPreviousClose
        : cl.at(-2),
      volume = Number.isFinite(m?.regularMarketVolume)
        ? m.regularMarketVolume
        : vol.at(-1);
    return {
      ...d,
      price: Number.isFinite(price) ? price : null,
      change:
        Number.isFinite(price) && Number.isFinite(prev) ? price - prev : null,
      volume: Number.isFinite(volume) ? volume : null,
      asOf: m?.regularMarketTime
        ? new Date(m.regularMarketTime * 1000).toISOString()
        : null,
      source: "Yahoo Finance · exchange-delayed",
    };
  } catch {
    return {
      ...d,
      price: null,
      change: null,
      volume: null,
      asOf: null,
      source: "Feed unavailable · CME/Euronext license required",
    };
  }
}
async function weather(p: (typeof places)[number]) {
  const r = await fetch(
    `https://api.open-meteo.com/v1/forecast?latitude=${p.lat}&longitude=${p.lon}&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,et0_fao_evapotranspiration&timezone=auto&forecast_days=7`,
    { next: { revalidate: 1800 } },
  );
  if (!r.ok) throw Error("weather");
  const j = await r.json();
  return {
    ...p,
    days: j.daily.time.map((date: string, i: number) => ({
      date,
      max: j.daily.temperature_2m_max[i],
      min: j.daily.temperature_2m_min[i],
      rain: j.daily.precipitation_sum[i],
      prob: j.daily.precipitation_probability_max[i],
      et0: j.daily.et0_fao_evapotranspiration[i],
    })),
  };
}
async function cotMarket(name: string, label: string) {
  const q = new URLSearchParams({
    $limit: "1",
    $order: "report_date_as_yyyy_mm_dd DESC",
    $where: `market_and_exchange_names='${name}'`,
  });
  const r = await fetch(
    `https://publicreporting.cftc.gov/resource/72hh-3qpy.json?${q}`,
    { next: { revalidate: 14400 } },
  );
  if (!r.ok) throw Error("cot");
  const x = (await r.json())[0] || {};
  return {
    label,
    date: x.report_date_as_yyyy_mm_dd?.slice(0, 10),
    long: +x.m_money_positions_long_all || 0,
    short: +x.m_money_positions_short_all || 0,
    spread: +x.m_money_positions_spread_all || 0,
    producerLong: +x.prod_merc_positions_long_all || 0,
    producerShort: +x.prod_merc_positions_short_all || 0,
    openInterest: +x.open_interest_all || 0,
  };
}
async function news() {
  const q = encodeURIComponent(
    "wheat (USDA OR crop OR export OR Black Sea OR Russia OR Ukraine OR Kansas OR drought) sourcelang:english",
  );
  const r = await fetch(
    `https://api.gdeltproject.org/api/v2/doc/doc?query=${q}&mode=artlist&maxrecords=60&format=json&sort=datedesc&timespan=30d`,
    { next: { revalidate: 900 } },
  );
  if (!r.ok) throw Error("news");
  const j = await r.json();
  return (j.articles || [])
    .map((x: any) => ({
      title: x.title,
      url: typeof x.url === "string" && /^https?:\/\//.test(x.url) ? x.url : "",
      domain: x.domain,
      date: x.seendate,
      category: /export|tender|shipment|black sea|russia|ukraine/i.test(x.title)
        ? "Trade"
        : /weather|drought|rain|heat|frost|crop condition/i.test(x.title)
          ? "Weather"
          : "Wheat",
      source: "GDELT discovery",
    }))
    .filter((x: any) => x.title && x.url);
}

export async function GET() {
  const [quotes, w, c, n] = await Promise.allSettled([
    Promise.all(quoteDefs.map(quote)),
    Promise.all(places.map(weather)),
    Promise.all([
      cotMarket("WHEAT-SRW - CHICAGO BOARD OF TRADE", "CBOT SRW"),
      cotMarket("WHEAT-HRW - CHICAGO BOARD OF TRADE", "KC HRW"),
      cotMarket("WHEAT-HRSpring - MINNEAPOLIS GRAIN EXCHANGE", "MGEX HRS"),
    ]),
    news(),
  ]);
  return Response.json(
    {
      generatedAt: new Date().toISOString(),
      contracts: quotes.status === "fulfilled" ? quotes.value : [],
      weather: w.status === "fulfilled" ? w.value : [],
      cot: c.status === "fulfilled" ? c.value : [],
      news: n.status === "fulfilled" ? n.value : [],
    },
    {
      headers: {
        "Cache-Control": "public, s-maxage=900, stale-while-revalidate=1800",
      },
    },
  );
}
