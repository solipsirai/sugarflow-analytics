export const dynamic = "force-dynamic";
const defs = [
  {
    symbol: "ZC=F",
    name: "CBOT Corn Front",
    month: "Front",
    status: "FRONT",
    roll: "Volume/OI crossover",
    lastTrade: "CME calendar",
  },
  {
    symbol: "ZCU26.CBT",
    name: "CBOT Corn Sep 2026",
    month: "Sep-26",
    status: "EXPIRING",
    roll: "Early Sep",
    lastTrade: "14 Sep 2026",
  },
  {
    symbol: "ZCZ26.CBT",
    name: "CBOT Corn Dec 2026",
    month: "Dec-26",
    status: "NEW CROP / LIQUID",
    roll: "07–11 Dec 2026",
    lastTrade: "14 Dec 2026",
  },
  {
    symbol: "ZCH27.CBT",
    name: "CBOT Corn Mar 2027",
    month: "Mar-27",
    status: "DEFERRED",
    roll: "08–12 Mar 2027",
    lastTrade: "12 Mar 2027",
  },
  {
    symbol: "EMA=F",
    name: "Euronext Corn Front",
    month: "Front",
    status: "VERIFY FEED",
    roll: "Euronext calendar",
    lastTrade: "Euronext calendar",
  },
];
const places = [
  {
    id: "iowa",
    name: "Des Moines, Iowa",
    region: "Central Corn Belt",
    stage: "Grain fill",
    lat: 41.59,
    lon: -93.62,
  },
  {
    id: "illinois",
    name: "Springfield, Illinois",
    region: "Eastern Corn Belt",
    stage: "Grain fill",
    lat: 39.8,
    lon: -89.64,
  },
  {
    id: "nebraska",
    name: "Grand Island, Nebraska",
    region: "Western Corn Belt",
    stage: "Grain fill / irrigation",
    lat: 40.93,
    lon: -98.34,
  },
  {
    id: "minnesota",
    name: "Mankato, Minnesota",
    region: "Northern Corn Belt",
    stage: "Dent / maturity",
    lat: 44.16,
    lon: -94.0,
  },
  {
    id: "indiana",
    name: "Indianapolis, Indiana",
    region: "Eastern Corn Belt",
    stage: "Grain fill",
    lat: 39.77,
    lon: -86.16,
  },
  {
    id: "ohio",
    name: "Columbus, Ohio",
    region: "Ohio Valley",
    stage: "Grain fill",
    lat: 39.96,
    lon: -83.0,
  },
  {
    id: "kansas",
    name: "Salina, Kansas",
    region: "Central Plains",
    stage: "Dryland stress watch",
    lat: 38.84,
    lon: -97.61,
  },
  {
    id: "dakota",
    name: "Sioux Falls, South Dakota",
    region: "Northern Plains",
    stage: "Dent / maturity",
    lat: 43.55,
    lon: -96.73,
  },
];
async function quote(d: any) {
  try {
    const r = await fetch(
      `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(d.symbol)}?interval=1d&range=5d`,
      {
        headers: { "User-Agent": "Mozilla/5.0 AgroFlow/1.0" },
        next: { revalidate: 900 },
      },
    );
    if (!r.ok) throw Error();
    const x = (await r.json())?.chart?.result?.[0],
      m = x?.meta,
      q = x?.indicators?.quote?.[0],
      cl = (q?.close || []).filter(Number.isFinite),
      vol = (q?.volume || []).filter(Number.isFinite),
      price = Number.isFinite(m?.regularMarketPrice)
        ? m.regularMarketPrice
        : cl.at(-1),
      prev = Number.isFinite(m?.chartPreviousClose)
        ? m.chartPreviousClose
        : cl.at(-2),
      volume = Number.isFinite(m?.regularMarketVolume)
        ? m.regularMarketVolume
        : vol.at(-1);
    return {
      ...d,
      price: Number.isFinite(price) ? price : null,
      change:
        Number.isFinite(price) && Number.isFinite(prev) ? price - prev : null,
      volume: Number.isFinite(volume) ? volume : null,
      asOf: m?.regularMarketTime
        ? new Date(m.regularMarketTime * 1000).toISOString()
        : null,
      source: "Yahoo Finance · exchange-delayed",
    };
  } catch {
    return {
      ...d,
      price: null,
      change: null,
      volume: null,
      asOf: null,
      source: "Feed unavailable · licensed CME/Euronext feed required",
    };
  }
}
async function weather(p: any) {
  const r = await fetch(
    `https://api.open-meteo.com/v1/forecast?latitude=${p.lat}&longitude=${p.lon}&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,et0_fao_evapotranspiration&timezone=auto&forecast_days=7`,
    { next: { revalidate: 1800 } },
  );
  if (!r.ok) throw Error();
  const j = await r.json();
  return {
    ...p,
    days: j.daily.time.map((date: string, i: number) => ({
      date,
      max: j.daily.temperature_2m_max[i],
      min: j.daily.temperature_2m_min[i],
      rain: j.daily.precipitation_sum[i],
      prob: j.daily.precipitation_probability_max[i],
      et0: j.daily.et0_fao_evapotranspiration[i],
    })),
  };
}
async function cot() {
  const q = new URLSearchParams({
    $limit: "1",
    $order: "report_date_as_yyyy_mm_dd DESC",
    $where: "market_and_exchange_names='CORN - CHICAGO BOARD OF TRADE'",
  });
  const r = await fetch(
    `https://publicreporting.cftc.gov/resource/72hh-3qpy.json?${q}`,
    { next: { revalidate: 14400 } },
  );
  if (!r.ok) throw Error();
  const x = (await r.json())[0] || {};
  return {
    date: x.report_date_as_yyyy_mm_dd?.slice(0, 10),
    long: +x.m_money_positions_long_all || 0,
    short: +x.m_money_positions_short_all || 0,
    spread: +x.m_money_positions_spread_all || 0,
    producerLong: +x.prod_merc_positions_long_all || 0,
    producerShort: +x.prod_merc_positions_short_all || 0,
    openInterest: +x.open_interest_all || 0,
  };
}
async function news() {
  const q = encodeURIComponent(
    "(corn OR maize) (USDA OR crop OR ethanol OR export OR Brazil OR China OR weather) sourcelang:english",
  );
  const r = await fetch(
    `https://api.gdeltproject.org/api/v2/doc/doc?query=${q}&mode=artlist&maxrecords=75&format=json&sort=datedesc&timespan=30d`,
    { next: { revalidate: 900 } },
  );
  if (!r.ok) throw Error();
  const j = await r.json();
  return (j.articles || [])
    .map((x: any) => ({
      title: x.title,
      url: typeof x.url === "string" && /^https?:\/\//.test(x.url) ? x.url : "",
      domain: x.domain,
      date: x.seendate,
      category: /ethanol|biofuel/i.test(x.title)
        ? "Ethanol"
        : /weather|drought|rain|heat|crop condition/i.test(x.title)
          ? "Weather"
          : /export|import|china|shipment|tender/i.test(x.title)
            ? "Trade"
            : "Corn",
      source: "GDELT discovery",
    }))
    .filter((x: any) => x.title && x.url);
}
export async function GET() {
  const [q, w, c, n] = await Promise.allSettled([
    Promise.all(defs.map(quote)),
    Promise.all(places.map(weather)),
    cot(),
    news(),
  ]);
  return Response.json(
    {
      generatedAt: new Date().toISOString(),
      contracts: q.status === "fulfilled" ? q.value : [],
      weather: w.status === "fulfilled" ? w.value : [],
      cot: c.status === "fulfilled" ? c.value : null,
      news: n.status === "fulfilled" ? n.value : [],
    },
    {
      headers: {
        "Cache-Control": "public, s-maxage=900, stale-while-revalidate=1800",
      },
    },
  );
}
