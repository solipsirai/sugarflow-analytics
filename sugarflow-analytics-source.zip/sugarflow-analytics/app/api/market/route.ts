export const dynamic = "force-dynamic";
type ContractQuote = {
  symbol: string;
  name: string;
  price: number | null;
  change: number | null;
  volume: number | null;
  currency: string;
  unit: string;
  asOf: string | null;
  source: string;
  status: "delayed" | "unavailable";
  contractState: string;
  lastTrade: string | null;
  rollWatch: string | null;
};
const places = [
  {
    id: "brazil",
    name: "Ribeirão Preto, BR",
    lat: -21.17,
    lon: -47.81,
    stage: "Harvest / Crush",
  },
  {
    id: "india",
    name: "Maharashtra, IN",
    lat: 19.75,
    lon: 75.71,
    stage: "Monsoon / Growth",
  },
  {
    id: "thailand",
    name: "Khon Kaen, TH",
    lat: 16.44,
    lon: 102.84,
    stage: "Growth",
  },
];
async function weather(p: (typeof places)[number]) {
  const r = await fetch(
    `https://api.open-meteo.com/v1/forecast?latitude=${p.lat}&longitude=${p.lon}&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max&timezone=auto&forecast_days=7`,
    { next: { revalidate: 1800 } },
  );
  if (!r.ok) throw Error("weather");
  const j = await r.json();
  return {
    ...p,
    days: j.daily.time.map((date: string, i: number) => ({
      date,
      max: j.daily.temperature_2m_max[i],
      min: j.daily.temperature_2m_min[i],
      rain: j.daily.precipitation_sum[i],
      prob: j.daily.precipitation_probability_max[i],
    })),
  };
}
async function fx() {
  const r = await fetch("https://api.frankfurter.app/latest?from=USD&to=BRL", {
    next: { revalidate: 3600 },
  });
  if (!r.ok) throw Error("fx");
  const j = await r.json();
  return { value: j.rates.BRL, date: j.date };
}
async function cot() {
  const q = new URLSearchParams({
    $limit: "1",
    $order: "report_date_as_yyyy_mm_dd DESC",
    $where: "market_and_exchange_names like 'SUGAR NO. 11%'",
  });
  const r = await fetch(
    `https://publicreporting.cftc.gov/resource/72hh-3qpy.json?${q}`,
    { next: { revalidate: 14400 } },
  );
  if (!r.ok) throw Error("cot");
  const x = (await r.json())[0] || {};
  return {
    date: x.report_date_as_yyyy_mm_dd?.slice(0, 10),
    moneyLong: +x.m_money_positions_long_all || 0,
    moneyShort: +x.m_money_positions_short_all || 0,
    producerLong: +x.prod_merc_positions_long_all || 0,
    producerShort: +x.prod_merc_positions_short_all || 0,
    openInterest: +x.open_interest_all || 0,
  };
}
const decodeXml = (s: string) =>
  s
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
    .replace(/&amp;/g, "&")
    .replace(/&#8217;/g, "’")
    .replace(/&#038;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/<[^>]+>/g, "")
    .trim();
function category(title: string) {
  const t = title.toLowerCase();
  if (/ethanol|biofuel|e10|e20|fuel blend|molasses/.test(t)) return "Etanol";
  if (/brazil|brasil|unica|center-south|são paulo/.test(t)) return "Brezilya";
  if (/india|indian|maharashtra|uttar pradesh|isma|dgft/.test(t))
    return "Hindistan";
  if (
    /government|policy|tariff|quota|import duty|export ban|mandate|minister|regulation/.test(
      t,
    )
  )
    return "Politika";
  return "Şeker";
}
async function chinimandiNews() {
  const r = await fetch("https://www.chinimandi.com/feed/", {
    headers: {
      "User-Agent": "Mozilla/5.0 SugarFlow/1.0",
      Accept: "application/rss+xml, application/xml, text/xml",
    },
    next: { revalidate: 900 },
  });
  if (!r.ok) throw Error("chinimandi");
  const xml = await r.text();
  return [...xml.matchAll(/<item>([\s\S]*?)<\/item>/gi)]
    .map((m) => {
      const item = m[1],
        pick = (tag: string) =>
          decodeXml(
            item.match(
              new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, "i"),
            )?.[1] || "",
          );
      const title = pick("title"),
        raw = pick("link"),
        url = raw.startsWith("https://www.chinimandi.com/") ? raw : "";
      return {
        title,
        url,
        domain: "ChiniMandi",
        date: pick("pubDate"),
        image: null,
        language: "English",
        category: category(title),
        source: "ChiniMandi RSS",
      };
    })
    .filter((x) => x.title && x.url);
}
async function gdeltNews() {
  const q = encodeURIComponent(
    "(sugar market OR sugarcane OR ethanol Brazil OR India sugar) sourcelang:english",
  );
  const r = await fetch(
    `https://api.gdeltproject.org/api/v2/doc/doc?query=${q}&mode=artlist&maxrecords=75&format=json&sort=datedesc&timespan=1y`,
    { next: { revalidate: 900 } },
  );
  if (!r.ok) throw Error("news");
  const j = await r.json();
  return (j.articles || [])
    .map((x: any) => {
      const url =
        typeof x.url === "string" && /^https?:\/\//.test(x.url) ? x.url : "";
      return {
        title: x.title,
        url,
        domain: x.domain,
        date: x.seendate,
        image: x.socialimage || null,
        language: x.language || "English",
        category: category(x.title || ""),
        source: "GDELT",
      };
    })
    .filter((x: any) => x.title && x.url);
}
async function news() {
  const settled = await Promise.allSettled([chinimandiNews(), gdeltNews()]);
  const merged = settled.flatMap((x) =>
    x.status === "fulfilled" ? x.value : [],
  );
  return [...new Map(merged.map((x) => [x.url, x])).values()].slice(0, 100);
}
const contractDefs = [
  {
    symbol: "SB=F",
    name: "NY #11 Raw Sugar (front)",
    unit: "US¢/lb",
    contractState: "FRONT / ACTIVE",
    lastTrade: null,
    rollWatch: null,
  },
  {
    symbol: "SBV26.NYB",
    name: "NY #11 Oct 2026",
    unit: "US¢/lb",
    contractState: "ACTIVE",
    lastTrade: "2026-09-30",
    rollWatch: "2026-09-23",
  },
  {
    symbol: "SBH27.NYB",
    name: "NY #11 Mar 2027",
    unit: "US¢/lb",
    contractState: "NEXT",
    lastTrade: "2027-02-26",
    rollWatch: "2027-02-19",
  },
  {
    symbol: "SBK27.NYB",
    name: "NY #11 May 2027",
    unit: "US¢/lb",
    contractState: "DEFERRED",
    lastTrade: "2027-04-30",
    rollWatch: "2027-04-23",
  },
  {
    symbol: "SW=F",
    name: "London #5 White Sugar (front)",
    unit: "USD/MT",
    contractState: "FRONT / ACTIVE",
    lastTrade: null,
    rollWatch: null,
  },
];
async function quote(d: (typeof contractDefs)[number]): Promise<ContractQuote> {
  try {
    const r = await fetch(
      `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(d.symbol)}?interval=1d&range=5d`,
      {
        headers: { "User-Agent": "Mozilla/5.0 SugarFlow/1.0" },
        next: { revalidate: 900 },
      },
    );
    if (!r.ok) throw Error("quote");
    const x = (await r.json())?.chart?.result?.[0],
      m = x?.meta,
      q = x?.indicators?.quote?.[0],
      cl = q?.close?.filter((v: any) => Number.isFinite(v)) || [],
      vol = q?.volume?.filter((v: any) => Number.isFinite(v)) || [];
    const price = Number.isFinite(m?.regularMarketPrice)
        ? m.regularMarketPrice
        : cl.at(-1),
      prev = Number.isFinite(m?.chartPreviousClose)
        ? m.chartPreviousClose
        : cl.at(-2),
      volume = Number.isFinite(m?.regularMarketVolume)
        ? m.regularMarketVolume
        : vol.at(-1);
    return {
      ...d,
      price: Number.isFinite(price) ? price : null,
      change:
        Number.isFinite(price) && Number.isFinite(prev) ? price - prev : null,
      volume: Number.isFinite(volume) ? volume : null,
      currency: m?.currency || "USD",
      asOf: m?.regularMarketTime
        ? new Date(m.regularMarketTime * 1000).toISOString()
        : null,
      source: "Yahoo Finance · exchange-delayed",
      status: Number.isFinite(price) ? "delayed" : "unavailable",
    };
  } catch {
    return {
      ...d,
      price: null,
      change: null,
      volume: null,
      currency: "USD",
      asOf: null,
      source: "Yahoo Finance · unavailable",
      status: "unavailable",
    };
  }
}
async function contracts() {
  return Promise.all(contractDefs.map(quote));
}
export async function GET() {
  const [w, f, c, n, q] = await Promise.allSettled([
    Promise.all(places.map(weather)),
    fx(),
    cot(),
    news(),
    contracts(),
  ]);
  return Response.json(
    {
      generatedAt: new Date().toISOString(),
      weather: w.status === "fulfilled" ? w.value : null,
      fx: f.status === "fulfilled" ? f.value : null,
      cot: c.status === "fulfilled" ? c.value : null,
      news: n.status === "fulfilled" ? n.value : [],
      contracts: q.status === "fulfilled" ? q.value : [],
    },
    {
      headers: {
        "Cache-Control": "public, s-maxage=900, stale-while-revalidate=1800",
      },
    },
  );
}
